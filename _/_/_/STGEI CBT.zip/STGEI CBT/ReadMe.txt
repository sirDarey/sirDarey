OVERVIEW AND FEATURES

This is a Windows App created with Java FX. 
It works with MySQL database which provides the resources for the app such as questions and answers.
The Structure of the CBT involves a choice of 4 subjects (from a total of 11 subjects) which offers a total of 180 questions to be attempted within 120 mins.
Each subject has about 100 questions or more from which 40 random questions will be generated.
The random functionality implies that different candidates will see different questions. No 2 candidates will have exactly the same set of questions.
The app also features in-built Basic CALCULATOR and a CountDown TIMER.
It saves questions, answers and Timer automiatically even in scenarios like Power Failure. You just have to continue from where you left.
It's a one time exam. No candidate is allowed to take same exam twice.
Grading is ON THE SPOT.
You can register new candidates and check results of Submitted Attempts (From the Server System Only)

STEPS TO RUN APP

1. Import the "preexam.sql" file into MySQL Database
2. Run the jar file directly or from CMD
3. Locate "Register a new Candidate" and register a demo candidate
4. Login with the Student Code created as Username (In Upper case) and surname as password (In Lower case)
5. You're good to EXPLORE!
6. If you want to connect one or more clients to the server, you have to check the ip of the server's system.
7. Connect the server and client to a single network via Wi-Fi or Network Cables Connected to a Hub.
8. Go to "Change IP" on the Login Page and Enter the Server's IP; Only then, will the client be able to communicate with the server as long as they are on the same network.
9. Recall, only  the server can register new candidate and also check results.