-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2022 at 09:26 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `preexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(50) NOT NULL DEFAULT '0',
  `bimage` varchar(100) NOT NULL,
  `cimage` varchar(100) NOT NULL,
  `dimage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'In preparing the final accounts, the bad debt account is closed by a transfer to the', 'balance sheet', 'provision for bad debt account', 'profit and loss account', 'treading account', 'c', 'Answer All Quetions', '', '', '', '', ''),
(2, 'Determine the cost of goods sold', 'N2575', 'N2985', 'N3250', 'N3925', 'b', 'Answer All Quetions', 'acc1.png', '', '', '', ''),
(3, 'In a petty cash book the imprest is N1380.\r\nHow much was received to maintain the imprest at the end of the month?', 'N 950', 'N 970', 'N430', 'N380', 'a', 'Answer All Quetions', 'acc2.png', '', '', '', ''),
(4, 'The income statement for the year ended June 30, 2001 is shown above. A miscellaneous expense is 10% of the revenue. Calculate the net income', 'N 583,000', 'N 563, 000', 'N 483,000', 'N 683,000', 'a', 'Answer All Quetions', 'acc3.png', '', '', '', ''),
(5, 'An entry in a subsidiary book which does not form part of the double entry system is a ', 'contra entry', 'journal entry', 'single entry', 'memorandum entry', 'd', 'Answer All Quetions', '', '', '', '', ''),
(6, 'In an incomplete record, the preparation of bank reconciliation ensures that', 'all cash takings are banked', 'the cash book is correct', 'there are no overdraft', 'there are no hidden loan', 'b', 'Answer All Quetions', '', '', '', '', ''),
(7, 'I. Fixtures account II. Machinery  account III. Wages account IV. Rent account\r\nWhich of the above are nominal accounts?', 'III and IV', 'I and II', 'I and III', 'II and III', 'a', 'Answer All Quetions', '', '', '', '', ''),
(8, 'NAFARA & SONS Balance sheet as at 31st December, 1987 is shown above.\r\nCompute the value of current assets', 'N 20400', 'N 20465', 'N 35695', 'N 19820', 'a', 'Answer All Quetions', 'acc4.png', '', '', '', ''),
(9, 'The value of money invested by the owners is', 'N 110,000', 'N 105,000', 'N 101,000', 'N 100,000', 'c', 'Answer All Quetions', 'acc5.png', '', '', '', ''),
(10, 'The liabilities of Udo Co. Ltd is', 'N 180,000', 'N 181,000', 'N 177,000', 'N 110,000', 'a', 'Answer All Quetions', 'acc5.png', '', '', '', ''),
(11, 'The normal accounting entry to record the dishonor of a cheque by a business man is', 'debit cash book and credit suspense account', 'debit cash book and credit drawer', 'credit cash book and debit suspense account', 'credit cash book and debit drawer', 'd', 'Answer All Quetions', '', '', '', '', ''),
(12, 'What is the working capital?', 'N 90m', 'N 70m', 'N 100m', 'N 80m', 'a', 'Answer All Quetions', 'acc6.png', '', '', '', ''),
(13, 'Determine the value of the trade investment', 'N 8m', 'N 10m', 'N 15m', 'N 20m', 'b', 'Answer All Quetions', 'acc6.png', '', '', '', ''),
(14, 'The concise statement used to explain entries in general journal is known as', 'narration', 'summary', 'information', 'commentary', 'a', 'Answer All Quetions', '', '', '', '', ''),
(15, 'If the total expenses is N20845, what will the net profit for the company during the month?', 'N 19149', 'N 16168', 'N 21655', 'N 18405', 'd', 'Answer All Quetions', 'acc7.png', '', '', '', ''),
(16, 'The closing stock for the company is', 'N 72000', 'N45000', 'N42500', 'N31250', 'd', 'Answer All Quetions', 'acc7.png', '', '', '', ''),
(17, 'In a departmental accounting system, which of the following expenses will most likely be apportioned on the basis of turnover?', 'carriage outwards', 'carriage inwards', 'discounts received', 'return outward', 'a', 'Answer All Quetions', '', '', '', '', ''),
(18, 'Determine the prime cost', 'N 7500', 'N 6500', 'N 9000', 'N 8000', 'c', 'Answer All Quetions', 'acc8.png', '', '', '', ''),
(19, 'The cost of goods manufactured is', 'N 11000', 'N 12000', 'N 14000', 'N 9000', 'a', 'Answer All Quetions', 'acc8.png', '', '', '', ''),
(20, 'I. Orientation II. Entity III. Legal status IV. Finance\r\nWhich of the characteristics above distinguishes a profit-making from a not-for-profit-making organization?', 'I, II, III and IV', 'I, II and III', 'II and III', 'I and II', 'a', 'Answer All Quetions', '', '', '', '', ''),
(21, 'What is the gross profit carried to the profit and loss account?', 'N 1820', 'N 1640', 'N 1530', 'N 1870', 'a', 'Answer All Quetions', 'acc9.png', '', '', '', ''),
(22, 'Calculate the cost of goods credited to the head office treading account.', 'N 7660', 'N 7500', 'N 7460', 'N 7200', 'a', 'Answer All Quetions', 'acc9.png', '', '', '', ''),
(23, 'Nasara Manufacturing Plc has three direct labour employees that work 40 hours each a week for 50 weeks a year. Factory overhead costs of N60, 000 is distributed on the basis of direct labour hours. Compute the overhead rate.', 'N12 per hour', 'N16 per hour', 'N10 per hour', 'N15 per hour', 'c', 'Answer All Quetions', '', '', '', '', ''),
(24, 'Subscription received is always put at 125% of the total donations received and refreshment sales.\r\nWhat is the closing cash balance?', 'N 11500', 'N 12000', 'N 13000', 'N 13500', 'a', 'Answer All Quetions', 'acc10.png', '', '', '', ''),
(25, 'Subscription received is always put at 125% of the total donations received and refreshment sales.\r\nCompute the subscription received', 'N 30000', 'N 28000', 'N 24000', 'N 20000', 'd', 'Answer All Quetions', 'acc10.png', '', '', '', ''),
(26, 'Discount allowed and received are apportioned to the two departments on the basis of departmental sales and purchases. \r\nDepartment P\'s share of discount received is', 'N750', 'N1000', 'N250', 'N500', 'c', 'Answer All Quetions', 'acc11.png', '', '', '', ''),
(27, 'Discount allowed and received are apportioned to the two departments on the basis of departmental sales and purchases.\r\nWhat is department Q\'s share of discount allowed?', 'N2000', 'N1500', 'N800', 'N1200', 'c', 'Answer All Quetions', 'acc11.png', '', '', '', ''),
(28, 'It is the tradition of the club to write off an amount equal to 25% of the subscriptions received as other expenses.\r\nWhat is the amount to be written off as other expenses?', 'N4500', 'N6000', 'N4000', 'N5000', 'd', 'Answer All Quetions', 'acc12.png', '', '', '', ''),
(29, 'It is the tradition of the club to write off an amount equal to 25% of the subscriptions received as other expenses.\r\nDetermine the club\'s excess of income over expenditure.', 'N12000', 'N15000', 'N10000', 'N14500', 'a', 'Answer All Quetions', 'acc12.png', '', '', '', ''),
(30, 'The gross profit on manufactured goods is the difference between the cost of goods manufactured and the ...', 'market value of goods produced', 'prime cost of production', 'indirect cost of production', 'goods produced', 'a', 'Answer All Quetions', '', '', '', '', ''),
(31, 'Given that 1/3 of the N6000 stock held by a branch is purchased from outsiders. If goods are invoiced to branch at 25% on cost, the provision for unrealized profit is', 'N1000.00', 'N333.33', 'N666.66', 'N800.00', 'd', 'Answer All Quetions', '', '', '', '', ''),
(32, 'The working capital of the club is', 'N5000', 'N4000', 'N3000', 'N7000', 'c', 'Answer All Quetions', 'acc13.png', '', '', '', ''),
(33, 'Costs that vary in proportion to the level of production in a manufacturing environment are known as', 'control costs', 'overheads', 'direct costs', 'indirect cost', 'c', 'Answer All Quetions', '', '', '', '', ''),
(34, 'A company operating a chain of retail provision stores invoices to the branches at cost plus a mark-up of 25%. What is the mark-up percentage on selling price?', '35%', '30%', '20%', '15%', 'c', 'Answer All Quetions', '', '', '', '', ''),
(35, 'Calculate the purchases for the prepaid.', 'N80,000', 'N35,000', 'N105,000', 'N70,000', 'b', 'Answer All Quetions', 'acc14.png', '', '', '', ''),
(36, 'Which method of pricing can be used satisfactorily in either a rising or falling price situation?', 'standard price', 'market price', 'FIFO', 'average method', 'a', 'Answer All Quetions', '', '', '', '', ''),
(37, 'Calculate the profit or loss.', 'N8500 loss', 'N2000 loss', 'N2000 profit', 'N8500 profit', 'c', 'Answer All Quetions', 'acc15.png', '', '', '', ''),
(38, 'In a control account, discount received is found on the', 'debit side of the purchases ledger control account', 'debit side of the sales ledger control account', 'credit side of the purchases ledger control account', 'credit side of the sales ledger control account', 'a', 'Answer All Quetions', '', '', '', '', ''),
(39, 'In a complete record system, a trading account cannot be prepared until the', 'day book has been balanced', 'amount of personal drawings has been established', 'cash book has been balanced', 'amount of sales and purchases has been established', 'd', 'Answer All Quetions', '', '', '', '', ''),
(40, 'The closing stock on March 11 by LIFO valuation is', 'N4200', 'N2700', 'N4500', 'N3900', 'd', 'Answer All Quetions', 'acc16.png', '', '', '', ''),
(41, 'The value of closing stock as at February 14 by simple average method is', 'N3900', 'N2500', 'N4100', 'N2700', 'b', 'Answer All Quetions', 'acc16.png', '', '', '', ''),
(42, 'Given an incomplete record without sufficient information to determine profit, the necessary thing to do is to', 'draw up the statement of affairs', 'draw up a T-account to establish the amount', 'compare the journal entries with the cash book', 'cross-check the cash book for further information', 'a', 'Answer All Quetions', '', '', '', '', ''),
(43, 'Control accounts help to verify the arithmetic accuracy of the postings from the', 'subsidiary book into the trial balance', 'ledgers into the trial balance', 'Journals into the ledger', 'subsidiary books into the ledgers', 'd', 'Answer All Quetions', '', '', '', '', ''),
(44, 'Keeping records under the single entry system has the advantage of', 'quality in terms of records', 'completenesss in terms of records', 'accuracy in terms of operation', 'simplicity in terms of operation', 'd', 'Answer All Quetions', '', '', '', '', ''),
(45, 'If the gross profit is N66,000, what is the value of stock at 31st December?', 'N30,000', 'N40,000', 'N50,000', 'N20,000', 'a', 'Answer All Quetions', 'acc17.png', '', '', '', ''),
(46, 'What is the opening balance on the consolidated revenue fund account?', 'N10, 000m', 'N12, 000m', 'N90, 000m', 'N11, 000m', 'a', 'Answer All Quetions', 'acc18.png', '', '', '', ''),
(47, 'Abba\'s capital balance at the end of the year will be', 'N5475', 'N5725', 'N4400', 'N5000', 'd', 'Answer All Quetions', 'acc19.png', '', '', '', ''),
(48, 'Current account balance of Kaka at the end of the year will be', 'N250', 'N350', 'N175', 'N325', 'a', 'Answer All Quetions', 'acc19.png', '', '', '', ''),
(49, 'Upon the dissolution of the partnership, the partnership Act provides that the amount realized should be', 'used to pay all taxes due to government', 'used to start a new partnership business by members who are willing', 'shared equally by the existing partners', 'used in paying the debts and liabilities of the firm to person who are not partners', 'd', 'Answer All Quetions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(10) NOT NULL,
  `un` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `ans` text NOT NULL,
  `score1` int(3) NOT NULL,
  `score2` int(3) NOT NULL,
  `score3` int(3) NOT NULL,
  `score4` int(3) NOT NULL,
  `tscore` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `biology`
--

CREATE TABLE `biology` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(100) NOT NULL,
  `bimage` varchar(100) NOT NULL,
  `cimage` varchar(100) NOT NULL,
  `dimage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `biology`
--

INSERT INTO `biology` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'Regulation of blood sugar level takes place in the', 'pancreas ', 'ileum ', 'liver ', 'kidney', 'c', 'Answer all Questions', '', '', '', '', ''),
(2, 'The manufacture of carbohydrates by plants take place in ', 'the leaves', 'the green stems', 'chlorophyllous parts', 'flowering plants', 'c', 'Answer all Questions', '', '', '', '', ''),
(3, 'The part of the brain that controls body posture in mammals is ', 'thalamus', 'cerebellum', 'spinal cord', 'cerebrum', 'b', 'Answer all Questions', '', '', '', '', ''),
(4, 'Peripheral arrangement of the vascular tissue in dicots is a characteristic of the internal structure of the ', 'leaf', 'petiole', 'stem', 'root', 'c', 'Answer all Questions', '', '', '', '', ''),
(5, 'An association between the root nodule of a leguminous plant and rhizobium is known as ', 'commensalism', 'mycorrhiza', 'parasitism', 'symbiosis', 'b', 'Answer all Questions', '', '', '', '', ''),
(6, 'Viviparity occurs mainly in ', 'mammals', 'reptiles', 'aves ', 'amphibians', 'a', 'Answer all Questions', '', '', '', '', ''),
(7, 'Which of the following structural features are adapted for uses other than water conservation? ', 'Succulent stems', 'Scales in animals', 'Spines in plants', 'Feathers in birds', 'a', 'Answer all Questions', '', '', '', '', ''),
(8, 'Surplus red blood cells needed to meet an emergency are usually stored in what organ of the body? ', 'Pancreas', 'Spleen', 'Liver', 'Kidney', 'b', 'Answer all Questions', '', '', '', '', ''),
(9, 'When a human donor gives a pint of blood, it usually require how many weeks for the body’s reserve of red corpuscles to be replaced? ', '1 week', '3 weeks', '7 weeks', '21 weeks', 'c', 'Answer all Questions', '', '', '', '', ''),
(10, 'The major protein component of connective tissue in mammals that comprises most of the organic matter of skin, tendons, bones, and teeth, and occurs as fibrous inclusions in most other body structures is', 'elastin ', 'collagen', 'fatty acids', 'keratin', 'b', 'Answer all Questions', '', '', '', '', ''),
(11, 'Digestion of PROTEINS begin in which of the following organs? ', 'small intestines', 'colon', 'mouth', 'stomach', 'd', 'Answer all Questions', '', '', '', '', ''),
(12, 'What function does bile have in digestion?', 'emulsification of lipids', 'digestion of proteins', 'digestion of carbohydrates', 'None of the above', 'a', 'Answer all Questions', '', '', '', '', ''),
(13, 'When oil is poured into the breeding site of mosquitoes, it', 'deprives the larvae of water', 'kills the adults', 'suffocates the pupae', 'slows down egg development', 'c', 'Answer all Questions', '', '', '', '', ''),
(14, 'A noticeable adaptation of the animal to its aquatic habitat is the possession of', 'webbed digits', 'four limbs', 'a wide mouth', 'large eyes', 'a', 'Answer all Questions', '', '', '', '', ''),
(15, 'An insect whose economic importance is both harmful and benefit is the ', ' butterfly', 'mosquito', 'blackfly', 'tsetsefly', 'a', 'Answer all Questions', '', '', '', '', ''),
(16, 'The most important hormone that induces the ripening of fruit is ', 'Cytokinin', 'Indole acetic acid', 'Ethylene', 'Gibberellin', 'c', 'Answer all Questions', '', '', '', '', ''),
(17, 'In mammalian males, the excretory and reproductive system share the ', 'ureter', 'testes', 'vas deferens', 'urethra', 'd', 'Answer all Questions', '', '', '', '', ''),
(18, 'An example of a caryopsis is ', 'coconut', 'tomato', 'guava', 'maize grain', 'd', 'Answer all Questions', '', '', '', '', ''),
(19, 'If the pair of allelels for baldness is given as Bb, a female carrier will be denoted by', 'XBXb', 'XBXB', 'XbY', 'XBY', 'a', 'Answer all Questions', '', '', '', '', ''),
(20, 'Epigeal germination of a seed is characterized by', 'lack of growth of the hypocotyls', 'more rapid elongation of the hypocotyls than the epicotyls', 'more rapid elongation of the epicotyl than the hypocotyls', 'equal growth rate of both the hypocotyl and epicotyls', 'b', 'Answer all Questions', '', '', '', '', ''),
(21, 'Identical twins inherit their genes from', 'One egg and two sperms', 'two eggs and a sperm', 'the same egg and sperm', 'different eggs and sperms', 'c', 'Answer all Questions', '', '', '', '', ''),
(22, 'Paternity disputes can most accurately be resolved through the use of', 'DNA analysis', 'fingerprinting', 'tongue-rolling', 'blood group typing', 'a', 'Answer all Questions', '', '', '', '', ''),
(23, 'The most effective method of dealing with non-biodegradable pollution is by\r\n', 'burying', 'dumping', 'incineration', 'recycling', 'd', 'Answer all Questions', '', '', '', '', ''),
(24, 'Soil fertility can best be conserved and renewed by the activities of', 'microbes', 'earthworms', 'man', 'rodents\r\n', 'a', 'Answer all Questions', '', '', '', '', ''),
(25, 'An argument against Lamarck\'s theory of evolution is that', 'acquired traits cannot be passed onto the offspring', 'disuse of body part cannot weaken the part', 'disused part is dropped off in the offspring', 'traits cannot be acquired through constant use of body parts', 'a', 'Answer all Questions', '', '', '', '', ''),
(26, 'Mycorrhiza is an association between fungi and\r\n', 'roots of higher plants', 'ilamentous algae', 'bacteria', 'protozoans', 'a', 'Answer all Questions', '', '', '', '', ''),
(27, 'An organism that has been extensively used to test the chromosome theory of heredity is \r\n', 'Homo sapiens', 'Drosophila melanogaster', 'Zea Mays', 'Musea domestica', 'b', 'Answer all Questions', '', '', '', '', ''),
(28, 'The structure labelled \"M\" in the diagram is', 'quill', 'rachis', 'superior umbilicus', 'aftershaft', 'd', 'Answer all Questions', 'bio6.png', '', '', '', ''),
(29, 'If a woman who is a carrier of sickle cell trait (AS) married a man who is a sickler (SS) and they had four children how many of them would be normal', 'Three', 'Two', 'One', 'None', 'b', 'Answer all Questions', '', '', '', '', ''),
(30, 'Which of the following ecological factors are common to both terrestrial and aquatic habitats?', 'Rainfall, temperature, light and wind', 'Salinity, rainfall temperature and light', 'Tides, wind, rainfall and altitude', 'Ph,salinity, rainfall and humidity', 'a', 'Answer all Questions', '', '', '', '', ''),
(31, 'The blood which leaves the liver and moves to the heart has a higher concentration of', 'Glucose', 'Bile', ' Bile Pigments', 'Urea', 'c', 'Answer all Questions', '', '', '', '', ''),
(32, 'The following structures are used for breathing in toad except', 'Skin', 'alimentary system', 'Buccal cavity', 'Lung', 'b', 'Answer all Questions', '', '', '', '', ''),
(33, 'Which of the following groups is the most advanced?', 'Thallophytes', 'Pteridophytes', 'Gymnosperms', 'Bryophytes', 'c', 'Answer all Questions', '', '', '', '', ''),
(34, 'Which of these is a common property of cell ecosystems?', 'flow of energy', 'decomposition of organic matter', 'Energy flow and nutrient cycling', 'presence of plants and animals', 'c', 'Answer all Questions', '', '', '', '', ''),
(35, 'The amount of moisture in the air (relative humidity) can be measured by', 'rain guage', 'anemometer', 'hygrometer', 'hydrometer', 'c', 'Answer all Questions', '', '', '', '', ''),
(36, 'The condition known as cretinism is caused by the deficiencies', 'Thyroxin', 'Insulin', 'Vitamin - A', 'Adrenalin', 'a', 'Answer all Questions', '', '', '', '', ''),
(37, 'Amphibians are normally found', 'in water', 'on moist land', 'in water and moist land', 'on dry land and in water', 'c', 'Answer all Questions', '', '', '', '', ''),
(38, 'The veins of the leaf are formed by the', 'spongy mesophyll', 'palisade tissue', 'cambium cells', 'vascular bundles', 'd', 'Answer all Questions', '', '', '', '', ''),
(39, 'When specimen X is mixed with few drops of iodine solution, the appearance of a blue-black colour confirms X is', 'sucrose', 'glucose', 'starch', 'galactose', 'c', 'Answer all Questions', '', '', '', '', ''),
(40, 'Which of the following diseases is caused by a virus?', 'Plague', 'Polio', 'Tetanus', 'Leprosy', 'b', 'Answer all Questions', '', '', '', '', ''),
(41, 'The skeleton of an anthropod is principally composed of', 'tannin', 'lignin', 'chitin', 'pectin', 'c', 'Answer all Questions', '', '', '', '', ''),
(42, 'The transportation of oxygen and carbon (IV) oxide in mammals is carried out by', 'phagocytes', 'leucocytes', 'erythrocytes', 'thrombocytes', 'c', 'Answer all Questions', '', '', '', '', ''),
(43, 'The gas produced during tissues respiration can be identified by using', 'sodium hydroxide', 'calcium carbonate', 'copper sulphate', 'calcium hydroxide', 'd', 'Answer all Questions', '', '', '', '', ''),
(44, 'Urea formation occurs in the', 'liver', 'kidney', 'heart', 'lung', 'a', 'Answer all Questions', '', '', '', '', ''),
(45, 'The number of individual in a habitat is release to the unit space available to each organism is referred to as the', 'Birthrate', 'Density', 'Frequency', 'Mortality', 'b', 'Answer all Questions', '', '', '', '', ''),
(46, 'The major function of the cell membrane is that it', 'Is the sites of photosynthesis', 'Breakdown spindles', 'Synthesis protein', 'Delimits the cytoplasm', 'd', 'Answer all Questions', '', '', '', '', ''),
(47, 'A seedling grown in the dark is likely to be', 'sturdy', 'stunted', 'dormant', 'etiolated', 'd', 'Answer all Questions', '', '', '', '', ''),
(48, 'The center for learning and memory in the human brain is the', 'olfactory lobe', 'cerebrum', 'medulla oblongata', 'cerebellum', 'b', 'Answer all Questions', '', '', '', '', ''),
(49, 'The physical space occupied by an organism together with its functional role in the community can be described as', 'niche', 'environment', 'habitat', 'biome', 'a', 'Answer all Questions', '', '', '', '', ''),
(50, 'The highest percentage of energy in an ecosystem occurs at level of the', 'producers', 'primary consumers', 'secondary consumers', 'decomposer', 'a', 'Answer all Questions', '', '', '', '', ''),
(51, 'The epiphytic habitat can best be described as', 'aquatic', 'terrestrial', 'arboreal', 'estuarine', 'c', 'Answer all Questions', '', '', '', '', ''),
(52, 'In the diagram, the structure labelled II is the\r\n', 'spermathecal pore', 'cocoon ', 'clitellum ', 'chaetea ', 'c', 'Answer all Questions', 'bio1.JPG', '', '', '', ''),
(53, 'The organism is found in soils rich in\r\n', 'mud ', 'humus ', 'clay ', 'sand ', 'b', 'Answer all Questions', 'bio1.JPG', '', '', '', ''),
(54, 'The organelle responsible for heredity is labelled\r\n', 'I', 'II', 'III', 'IV', 'b', 'Answer all Questions', 'bio2.JPG', '', '', '', ''),
(55, 'The part labelled IV is the\r\n', 'mitochondrion ', 'cell wall', 'endoplasmic reticulum', 'nucleus ', 'c', 'Answer all Questions', 'bio2.JPG', '', '', '', ''),
(56, 'Use the diagram above to answer this question. Arrows represent directional movement materials. \r\nTransportation in the xylem is represented by\r\n', 'I', 'II', 'III', 'IV', 'd', 'Answer all Questions', 'bio3.JPG', '', '', '', ''),
(57, 'Use the diagram above to answer this question. Arrows represent directional movement materials. The arrow labelled ll represents the\r\n', 'release of oxygen ', 'intake of carbon (IV) oxide', 'movement of photosynthesis ', 'movement of nutrients ', 'a', 'Answer all Questions', 'bio3.JPG', '', '', '', ''),
(58, 'The developing embryo is usually contained in the part labelled\r\n', 'IV', 'III', 'II', 'I', 'c', 'Answer all Questions', 'bio4.JPG', '', '', '', ''),
(59, 'The function of the part labelled lll is to', 'produce egg cells', 'protect sperms during fertilization', 'secrete hormones during coitus', 'protect the developing embryo ', 'a', 'Answer all Questions', 'bio4.JPG', '', '', '', ''),
(60, 'Tertiary consumers within the web are\r\n', 'cat and lion only ', 'Man and lion only', 'man and cat only ', 'man, cat and lion ', 'd', 'Answer all Questions', 'bio5.JPG', '', '', '', ''),
(61, 'What would be the effect of taking the lion out of the web?', 'The number of organisms at each trophic level would increase', 'Man would occupy the apex of the web ', 'There would be more rabbit in the web ', 'The energy reaching the remaining trophic would be increase ', 'b', 'Answer all Questions', 'bio5.JPG', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `black_woman`
--

CREATE TABLE `black_woman` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `black_woman`
--

INSERT INTO `black_woman` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The \"promised Land\" means ', 'Paradise ', 'heaven ', 'Africa ', 'home land', 'c', 'Questions Based on BLACK WOMAN\r\n\r\nAnd now, high up on the baked pass at the heart of Summer, \r\nat the heart of noon, I come upon you, my Promised land\r\nAnd your beauty strikes me to the heart like the flash of an eagle.\r\n', '', '', '', '', ''),
(2, '\"And your beauty strikes me to the heart like the flash of an eagle \", is an example of', 'simile ', 'personification ', 'metaphor ', 'oxymoron', 'a', 'Questions Based on BLACK WOMAN\r\n\r\nAnd now, high up on the baked pass at the heart of Summer, \r\nat the heart of noon, I come upon you, my Promised land\r\nAnd your beauty strikes me to the heart like the flash of an eagle.\r\n', '', '', '', '', ''),
(3, 'The poet refers to the African land as', 'a land of slavery', 'a land of natural resources', 'a land of the colonial masters ', 'a land of beauty and black soil', 'd', 'Questions Based on BLACK WOMAN\r\n\r\nAnd now, high up on the baked pass at the heart of Summer, \r\nat the heart of noon, I come upon you, my Promised land\r\nAnd your beauty strikes me to the heart like the flash of an eagle.\r\n', '', '', '', '', ''),
(4, 'The poet of the above poem is ', 'Leopold Sedar Senghor ', 'Niyi Osundare ', 'Kumar Farouk Sesay', 'Dylon Thomas', 'a', 'Questions Based on BLACK WOMAN\r\n\r\nAnd now, high up on the baked pass at the heart of Summer, \r\nat the heart of noon, I come upon you, my Promised land\r\nAnd your beauty strikes me to the heart like the flash of an eagle.\r\n', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `caged_bird`
--

CREATE TABLE `caged_bird` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caged_bird`
--

INSERT INTO `caged_bird` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The caged bird represents', 'west Africa', 'African-American ', 'Americans in USA', 'African continent', 'b', 'Questions Based on THE CAGED BIRD\r\n\r\nThe caged bird sings \r\nWith a fearful trill\r\nOf things unknown\r\nBut longed for still', '', '', '', '', ''),
(2, 'The free bird represents ', 'the blacks', 'the whites ', 'the white USA', 'the colored USA', 'c', 'Questions Based on THE CAGED BIRD\r\n\r\nThe caged bird sings \r\nWith a fearful trill\r\nOf things unknown\r\nBut longed for still', '', '', '', '', ''),
(3, 'The rhyming scheme of the above poem is', 'aabb ', 'abcb ', 'abab ', 'bbaa', 'b', 'Questions Based on THE CAGED BIRD\r\n\r\nThe caged bird sings \r\nWith a fearful trill\r\nOf things unknown\r\nBut longed for still', '', '', '', '', ''),
(4, 'The poet of the above poem is ', 'John Donne ', 'Maya Angelou ', 'David Herbert Lawrence', 'T.S. Eliot', 'a', 'Questions Based on THE CAGED BIRD\r\n\r\nThe caged bird sings \r\nWith a fearful trill\r\nOf things unknown\r\nBut longed for still', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `chemistry`
--

CREATE TABLE `chemistry` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(200) NOT NULL,
  `btext` varchar(200) NOT NULL,
  `ctext` varchar(200) NOT NULL,
  `dtext` varchar(200) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chemistry`
--

INSERT INTO `chemistry` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The number of electrons in the K, L, N and M  shells of calcium are respectively', '2,8,8,2', '2,2,8,8', '2,8, 2,8', '8,8,2,2', 'c', 'Answer all Questions', '', '', '', '', ''),
(2, 'Which of  the following gases  contains the least number of atoms at s.t.p?', '4 moles of chlorine', '3 moles of ozone', '1 mole of butane', '7 moles of helium', 'd', 'Answer all Questions', '', '', '', '', ''),
(3, '', '2Y', 'Y', '2Z', 'Z', 'd', 'Answer all Questions', 'chm1.JPG', '', '', '', ''),
(4, 'What  mass  of  water  is  produced  when 8.0g  of  hydrogen  reacts  with  excess oxygen?\r\n[H = 1, O = 16]', '36.0g', '8.0g', '72.0g', '16.0g', 'c', 'Answer all Questions', '', '', '', '', ''),
(5, '', '0.6 mol per dm cube', '0.2 mol per dm cube', '0.4 mol per dm cube', '0.5 mol per dm cube', 'b', 'Answer all Questions', 'chm2.JPG', '', '', '', ''),
(6, '', '12', '14', '20', '32', 'd', 'Answer all Questions', 'chm3.JPG', '', '', '', ''),
(7, 'Four elements P, Q, R, and S have \r\natomic numbers 2, 6, 16 and 19 \r\nrespectively. Which of these elements is a metal?', 'S', 'R', 'Q', 'P', 'a', 'Answer all Questions', '', '', '', '', ''),
(8, 'If the gas is cooled, at what temperature will it start to condense? ', '125 degrees Celsius', '175 degrees Celsius', '150 degrees Celsius', '250 degrees Celsius', 'c', 'Answer all Questions', 'chm4.JPG', '', '', '', ''),
(9, 'How long does it take all the solid to melt?', '3.0 mins', '1.0 mins', '6.0 mins', '2.5 mins', 'a', 'Answer all Questions', 'chm4.JPG', '', '', '', ''),
(10, 'The  filter  in  a  cigarette  reduces  the nicotine content by', 'adsorption', 'burning', 'evaporation', 'absorption', 'a', 'Answer all Questions', '', '', '', '', ''),
(11, 'Pure solvents are obtained by', 'extraction', 'evaporation', 'distillation', 'condensation', 'c', 'Answer all Questions', '', '', '', '', ''),
(12, 'Environmental pollution is worsened by the release from automobile exhausts of', 'heavy metals', 'water vapour', 'steam', 'smoke', 'a', 'Answer all Questions', '', '', '', '', ''),
(13, 'Which of the following polymers is suitable for packaging and electrical insulation?', 'polystyrene', 'polycarbonate', 'polyethene', 'polyamide', 'a', 'Answer all Questions', '', '', '', '', ''),
(14, 'Which of the following mixtures is producer gas?', 'Carbon(iv)oxide and Hydrogen', 'Carbon(iv)oxide and Nitrogen', 'Carbon(ii)oxide and Hydrogen', 'Carbon(ii)oxide and Nitrogen', 'd', 'Answer all Questions', '', '', '', '', ''),
(15, '', 'a dehydrating agent', 'an oxidizing agent', 'a reducing agent', 'a catalyst', 'a', 'Answer all Questions', 'chm5.JPG', '', '', '', ''),
(16, 'A burning candle produces water and', 'carbon(II) oxide', 'carbon(IV) oxide', 'oxygen', 'hydrogen', 'b', 'Answer all Questions', '', '', '', '', ''),
(17, 'Which of the following pair of organic compounds are isomers?', 'benzene and methylbenzene', 'trichloromethane and  tetrachloromethane', 'but-1-ene and but-2-ene', 'ethanol and propanone', 'c', 'Answer all Questions', '', '', '', '', ''),
(18, '', 'esterification', 'polymerization', 'decarboxylation', 'substitution', 'b', 'Answer all Questions', 'chm22.JPG', '', '', '', ''),
(19, 'A trihydric alkanol is', 'phenol', 'glycol', 'glycerol', 'ethanol', 'c', 'Answer all Questions', '', '', '', '', ''),
(20, 'Catalytic hydrogenation of benzene produces', 'oil', 'margarine', 'cyclohexane', 'cyclohexene', 'c', 'Answer all Questions', '', '', '', '', ''),
(21, 'During  the  vulcanization  of  rubber, sulphur is added to', 'break down rubber polymer', 'lengthen the chain of rubber', 'act as catalyst', 'bind rubber molecules together', 'd', 'Answer all Questions', '', '', '', '', ''),
(22, 'The general formula for the alkanals is', 'RCHO', 'ROH', 'RCO', 'RCOOR\'', 'a', 'Answer all Questions', '', '', '', '', ''),
(23, 'Fermentation is the', 'breaking down of carbohydrate to glucose', 'conversion of sugar to alcohol in the presence of yeast', 'breaking  down  of  sugar  to carbohydrate', 'conversion of alcohol to sugar in the presence of yeast', 'b', 'Answer all Questions', '', '', '', '', ''),
(24, 'Pick out the odd compound', 'methyl benzene', 'ethanol', 'phenol', 'toluene', 'b', 'Answer all Questions', '', '', '', '', ''),
(25, '', 'positive', 'indeterminate', 'zero', 'negative', 'a', 'Answer all Questions', 'chm6.JPG', '', '', '', ''),
(26, 'Which of the following equations shows that a reaction is in equilibrium?', '', '', '', '', 'a', 'Answer all Questions', '', 'chm7a.JPG', 'chm7b.JPG', 'chm7c.JPG', 'chm7d.JPG'),
(28, 'What  current  in  amperes  will  deposit 2.7g of aluminium in 2 hours? [Al = 27]', '32', '8', '4', '16', 'c', 'Answer all Questions', '', '', '', '', ''),
(29, 'The  property  which  makes  alcohol soluble in water is the', 'covalent nature', 'hydrogen bonding', 'ionic character', 'boiling point', 'b', 'Answer all Questions', '', '', '', '', ''),
(30, 'Which of the following hydrogen halides has the highest entropy value?', 'HBr', 'HI', 'HCl', 'HF', 'd', 'Answer all Questions', '', '', '', '', ''),
(31, 'In the electrolysis of brine, the anode is', 'zinc', 'platinum', 'carbon', 'copper', 'c', 'Answer all Questions', '', '', '', '', ''),
(32, 'The formula of ethyl butanoate is', '', '', '', '', 'a', 'Answer all Questions', '', 'chm8a.JPG', 'chm8b.JPG', 'chm8c.JPG', 'chm8d.JPG'),
(33, 'The intermediate product formed when ethanol is progressively oxidized to ethanoic acid with potassium heptaoxodicromate(VI) is', 'ethanal', 'methanal', 'butanal', 'propanal', 'a', 'Answer all Questions', '', '', '', '', ''),
(34, 'The phenomenon whereby the atmospheric pressure equals the saturated vapour pressure is called', 'freezing', 'boiling', 'latent heat', 'normal pressure', 'b', 'Answer all Questions', '', '', '', '', ''),
(35, 'What is the change in the oxidation number of copper in the reaction above?', '0  to +1', '0 to +2', '+2 to +1', '+1 to 0', 'd', 'Answer all Questions', 'chm9.JPG', '', '', '', ''),
(36, 'Which of the following will increase the yield of R?', 'Using a large closed vessel', 'Increasing the temperature', 'Removing some S', 'Adding a positive catalyst', 'c', 'Answer all Questions', 'chm10.JPG', '', '', '', ''),
(37, 'The pollutant from petroleum spillage in rivers and lakes can best be dispersed by', 'pouring detergents', 'passing of ships through the area', 'pouring organic solvents', 'evaporation', 'a', 'Answer all Questions', '', '', '', '', ''),
(38, 'The IUPAC name of the following organic compound HOOC-COOH is', 'ethan-1,2-dioc acid', 'ethanoic acid', 'Oxalic acid', 'Propan-1,2-dioic acid', 'a', 'Answer all Questions', '', '', '', '', ''),
(39, 'The leachate of a certain plant ash is used in local soap-making because it contains', 'sodium hydroxide', 'sodium chloride and potassium hydroxide', 'potassium hydroxide', 'soluble carbonates and hydrogen carbonates', 'c', 'Answer all Questions', '', '', '', '', ''),
(40, '', '0.97g', '97.10g', '19.42g', '9.70g', 'a', 'Answer all Questions', 'chm11.JPG', '', '', '', ''),
(41, 'Which of the following chlorides would exhibit the least ionic character?', 'Lithium Chloride', 'Aluminium Chloride', 'Magnesium Chloride', 'Calcium Chloride', 'b', 'Answer all Questions', '', '', '', '', ''),
(42, 'The  chemical  used  for  coagulation in water purification is', 'calcium tetraoxosulphate(VI)', 'sodium tetraoxosulphate(VI)', 'copper tetraoxosulphate(VI)', 'aluminium tetraoxosulphate(VI)', 'd', 'Answer all Questions', '', '', '', '', ''),
(43, 'The  boiling  of  fat  and  aqueous  caustic soda is referred to as', 'saponification', 'esterification', 'acidification', 'hydrolysis', 'a', 'Answer all Questions', '', '', '', '', ''),
(44, 'The number of isomers formed by hexane is', '2', '3', '4', '5', 'd', 'Answer all Questions', '', '', '', '', ''),
(45, 'Ordinary  glass  is  manufactured  from silica, Calcium carbonate and', 'potassium carbonate', 'Baking powder', 'washing soda', 'potassium sulphate', 'c', 'Answer all Questions', '', '', '', '', ''),
(46, 'Which of the following is not produced if you mix vinegar(an acid) and sodium bicarbonate(an alkali or base) together?', 'Water', 'Salt', 'Carbon(IV)oxide', 'Air', 'd', 'Answer all Questions', '', '', '', '', ''),
(47, 'Which of the following substances, when dissolved in water, gives a solution with the lowest pH?  ', 'HI', 'Sodium Peroxide', 'Potassium oxide', 'hydrogen sulphide', 'd', 'Answer all Questions', '', '', '', '', ''),
(48, 'Which of the following molecular formulae represents an alcohol?', '', '', '', '', 'c', 'Answer all Questions', '', 'chm12a.JPG', 'chm12b.JPG', 'chm12c.JPG', 'chm12d.JPG'),
(49, 'Someone has accidentally spilled battery acid on his or her skin. The first aid treatment for this is to apply plenty of:', 'salt', 'water', 'vinegar', 'baking soda', 'b', 'Answer all Questions', '', '', '', '', ''),
(50, '', '', '', '', '', 'c', 'Answer all Questions', 'chm13.JPG', 'chm13a.JPG', 'chm13b.JPG', 'chm13c.JPG', 'chm13d.JPG'),
(51, 'Which of the following molecular formulae can represent a pair of mirror image isomers?', '', '', '', '', 'c', 'Answer all Questions', '', 'chm14a.JPG', 'chm14b.JPG', 'chm14c.JPG', 'chm14d.JPG'),
(52, 'Which of the following statements is true about the periodic table?', 'The non-metallic properties of the elements tend to decrease across each period', 'Elements in the same group have the same number of electron shell', 'The valence electrons of the elements increase progressively across the period', 'Elements in the same period have the same number of valence electrons', 'c', 'Answer all Questions', '', '', '', '', ''),
(53, 'A compound that gives a brick-red colour to a non-luminous flame is likely to contain ', 'copper ion', 'calcium ion', 'aluminium ion', 'sodium ion ', 'b', 'Answer all Questions', '', '', '', '', ''),
(54, 'The compound of sodium that is used in the manufacture of glass is ', 'NaCl', '', '', 'NaOH', 'b', 'Answer all Questions', '', '', 'chm15b.JPG', 'chm15c.JPG', ''),
(55, 'In the diagram above, the function of the concentrated sulphuric acid is to ', 'purify the gas', 'liquefy the gas', 'dry the gas', 'remove odour', 'c', 'Answer all Questions', 'chm17.png', '', '', '', ''),
(56, 'The petroleum fraction that is used in heating furnaces in industries is', 'lubricating oil', 'gasoline', 'diesel oil', 'kerosene', 'c', 'Answer all Questions', '', '', '', '', ''),
(57, '', 'Carbon(II)oxide', 'Carbon(IV)oxide', 'Oxygen', 'Nitrogen', 'c', 'Answer all Questions', 'chm16.JPG', '', '', '', ''),
(58, 'The partial pressure of oxygen in a sample of air is 452mmHg and the total pressure is 780mmHg. What is the mole fraction of oxygen?', '0.203', '0.579', '2.030', '5.790', 'b', 'Answer all Questions', '', '', '', '', ''),
(59, '', '581.000', '0.581', '5.810', '58.100', 'a', 'Answer all Questions', 'chm18.JPG', '', '', '', ''),
(60, 'A plastic material which cannot be softened by heat is said to be', 'biodegradable', 'ductile', 'thermosetting', 'thermoplastic', 'c', 'Answer all Questions', '', '', '', '', ''),
(61, '', 'propane', 'butane', 'pentane', 'hexane', 'a', 'Answer all Questions', 'chm19.JPG', '', '', '', ''),
(62, 'Most of the fatal explosions in coal mines are caused by', 'ethane', 'ethene', 'ethyne', 'methane', 'd', 'Answer all Questions', '', '', '', '', ''),
(63, 'Which of the following does not readily react with concentrated trixoxnitrate(V) acid?', 'Copper', 'Zinc', 'Iron', 'Tin', 'c', 'Answer all Questions', '', '', '', '', ''),
(64, '', '58.5g', '52.7g', '50g ', '52g', 'd', 'Answer all Questions', 'chm20.JPG', '', '', '', ''),
(65, 'Metals conduct an electric current due to the presence of ', 'bounded electrons', 'free mobile electrons', 'crystal lattice structure', 'vacant atomic orbitals', 'b', 'Answer all Questions', '', '', '', '', ''),
(66, 'Which one of the following oxides is amphoteric?', 'MgO', 'carbon(iv)oxide', 'aluminium oxide', 'CuO', 'c', 'Answer all Questions', '', '', '', '', ''),
(67, 'The position of equilibrium of an exothermic reaction can be shifted forward by', 'increasing pressure at constant temperature', 'decreasing pressure at constant temperature', 'increasing temperature at constant pressure', 'decreasing temperature at constant pressure', 'd', 'Answer all Questions', '', '', '', '', ''),
(68, 'A metal that cannot produce hydrogen from alkaline solution is ', 'Tin', 'Iron', 'Aluminium', 'Copper', 'b', 'Answer all Questions', '', '', '', '', ''),
(69, '', '', '', '', '', 'a', 'Answer all Questions', 'chm21.JPG', 'chm21a.JPG', 'chm21b.JPG', 'chm21c.JPG', 'chm21d.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `commerce`
--

CREATE TABLE `commerce` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `commerce`
--

INSERT INTO `commerce` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'Which of the following countries is not a  member  of the Organisation of Petroleum Exporting countries  (OPEC)', 'Mexico', 'Nigeria', 'Saudi Arabia', 'Venezuela', 'a', 'Answer all Questions', '', '', '', '', ''),
(2, 'Which of the following allows production to take place  ahead of demand?', 'Transporting', 'Wholesaling', 'Exporting', 'Warehousing', 'd', 'Answer all Questions', '', '', '', '', ''),
(3, 'The most important factor that delayed the development of commerce in Nigeria was', 'the inefficient means of communication', 'provision for bad debt account', 'the unavailability of infrastructural facilities', 'that there were few developed markets', 'c', 'Answer all Questions', '', '', '', '', ''),
(4, 'The major responsibility of an entrepreneur is', 'employing all factors of production in the business', 'coordinating and determining the proportion of what to produce', 'planning and organizing all activities in the business', 'directing and controlling all the affairs of the business', 'a', 'Answer all Questions', '', '', '', '', ''),
(5, 'The document issued to a port authority when goods are deposited is a', 'dock landing account', 'bill of sight', 'bill of lading', 'dock warrant', 'd', 'Answer all Questions', '', '', '', '', ''),
(6, 'Which of the  following has the main  objective to differentiate  between  Similar products from different  manufacturers', 'Branding', 'Wrapping', 'Packaging', 'Mark', 'a', 'Answer all Questions', '', '', '', '', ''),
(7, 'A device that enables the downloading of information from the internet is the', 'floppy drive', 'compact disk', 'bluetooth', 'modem', 'd', 'Answer all Questions', '', '', '', '', ''),
(8, 'Okeze contracted to sell TV sets to Ojo. Unknown to them, the sets were stolen in transit. This contract may be on the grounds of', 'bankruptcy', 'frustration', 'fraudulence', 'breach of contract', 'b', 'Answer all Questions', '', '', '', '', ''),
(9, 'Which of the following countries are members of the Lake Chad Basin Commission?', 'Niger and Cameroun', 'Benin and Nigeria', 'Chad and Benin', 'Nigeria and Mali', 'a', 'Answer all Questions', '', '', '', '', ''),
(10, 'The central working system of a computer used for data processing is the', 'hard drive', 'memory unit', 'monitor', 'floppy disk drive', 'b', 'Answer all Questions', '', '', '', '', ''),
(11, 'Capital as a factor of production can be used as', 'money that is regarded as assets', 'goods that are useful in business', 'input for further production', 'service that provides satisfaction', 'c', 'Answer all Questions', '', '', '', '', ''),
(12, 'The agency in Nigeria which ensures that products conform to government specifications is the', 'Standard Organization of Nigeria', 'Nigerian Consumers\' Association', 'Manufacturers Association of Nigeria', 'Nigeria Chambers of Commerce', 'a', 'Answer all Questions', '', '', '', '', ''),
(13, 'Awarding scholarship and sponsoring sports by a business organization are examples of', 'advertizing strategy', 'economic responsibility', 'marketing strategy', 'social responsibility', 'd', 'Answer all Questions', '', '', '', '', ''),
(14, 'The commercialization of public enterprise is aimed at', 'increasing the efficiency and   making the enterprise self-sufficient', 'advertizing and promoting the goods  and services of the enterprises', 'increased assistance and patronage of  the enterprises by the public', 'selling the goods and service of the enterprises', 'a', 'Answer all Questions', '', '', '', '', ''),
(15, 'An author\'s exclusive right to his published works is known as', 'author\'s right', 'constitutional right', 'patent right', 'copy right', 'd', 'Answer all Questions', '', '', '', '', ''),
(16, 'Under the endowment policy, the money handed over to the insured at the expiration of the stipulated time or at death is the', 'indemnity', 'surrender value', 'lump sum benefit', 'insurance premium', 'b', 'Answer all Questions', '', '', '', '', ''),
(17, 'The machine used for sending telex messages is known as a', 'radar', 'fax machine', 'dictaphone', 'teleprinter', 'd', 'Answer all Questions', '', '', '', '', ''),
(18, 'Which of these insurance principles requires a close connection between the actual loss suffered and the risk insured?', 'indemnity', 'proximate cause', 'contribution', 'subrogation', 'b', 'Answer all Questions', '', '', '', '', ''),
(19, 'The unit through which results of a processed data are displayed is the', 'logic unit', 'display unit', 'control unit', 'output unit', 'd', 'Answer all Questions', '', '', '', '', ''),
(20, 'Which of the following is used to inform the addressee that a registered parcel is ready for collection?', 'express label', 'counterfoil', 'telegram', 'slip', 'd', 'Answer all Questions', '', '', '', '', ''),
(21, 'The type of computer commonly found in offices is', 'laptop', 'desktop', 'the hybrid computer', 'the mainframe computer', 'b', 'Answer all Questions', '', '', '', '', ''),
(22, 'The mode of transporting crude oil to the ports for export purposes is by', 'tanker', 'rail', 'road', 'pipeline', 'd', 'Answer all Questions', '', '', '', '', ''),
(23, 'The temporary insurance certificate issued to the insured before drawing up a policy is a', 'cover note', 'testimonial', 'time policy', 'proposal form', 'a', 'Answer all Questions', '', '', '', '', ''),
(24, 'The bulls and bears in the Stock Exchange Market help to minimize', 'the number of shares and bonds sold', 'price increases of securities', 'fluctuation in price of securities', 'the elasticity of price of securities', 'c', 'Answer all Questions', '', '', '', '', ''),
(25, 'Debentures differs from shares in that', 'they are secured on the company\'s assets', 'ownership is open to the public', 'hey form part of the capital of the business', 'rewards are usually paid out of profit', 'a', 'Answer all Questions', '', '', '', '', ''),
(26, 'The Stock Exchange is a market where', 'long-term securities are sold', 'all types of securities are sold', 'short-term securities are sold', 'medium-term securities are sold', 'a', 'Answer all Questions', '', '', '', '', ''),
(27, 'A retail cooperative society aims at', 'hoarding manufactured goods', 'cutting off the profit of middle men', 'lending money to members at low interest rate', 'encouraging members to save money', 'b', 'Answer all Questions', '', '', '', '', ''),
(28, 'A bill of exchange already accepted can be discounted by the holder in', 'central bank', 'at least two banks', 'his bank', 'any bank', 'c', 'Answer all Questions', '', '', '', '', ''),
(29, 'The document issued by the seller which gives details of the goods is known as', 'catalogue', 'tender', 'price list', 'invoice', 'a', 'Answer all Questions', '', '', '', '', ''),
(30, 'Given:\r\nI. Retail	II. Export 	III.	Transport 	IV.	Import 	V. Insurance\r\nVI. Banking and finance	VII.	Wholesale	VIII.	Communication.\r\nWhich of the above are aids to Trade?\r\n', 'I, II, III and VIII', 'III, V, VI and VIII', 'I, II, III and IV', 'II, V, VI and VII', 'b', 'Answer all Questions', '', '', '', '', ''),
(31, 'The organizational structure that relates the positions of specialists to the line managers is called', 'line structure', 'staff structure', 'line and staff structure', 'functional structure', 'd', 'Answer all Questions', '', '', '', '', ''),
(32, 'A wholesaler who possesses the title to the goods he sells is known as', 'a merchant wholesaler', 'multiple wholesaler', 'a general wholesaler', 'an agent wholesaler', 'a', 'Answer all Questions', '', '', '', '', ''),
(33, 'An important principle of a good organizational structure is', 'ideal standard', 'span of control', 'clarity of mission', 'adequacy of resources', 'b', 'Answer all Questions', '', '', '', '', ''),
(34, 'A company that is registered with the Corporate Affairs Commission only without being enlisted on the Stock Exchange is a', 'public liability company', 'joint venture company', 'limited company', 'registered company', 'c', 'Answer all Questions', '', '', '', '', ''),
(35, 'A contract for the sale of goods involves the', 'producer, seller and the buyer of good', 'offering of goods to customers', 'transfer of the title to goods for money', 'exchange of goods', 'c', 'Answer all Questions', '', '', '', '', ''),
(36, 'The total of the share capital which a company could be allowed to issued is known as', 'called-up capital', 'paid up capital', 'nominal capital', 'issued capital', 'c', 'Answer all Questions', '', '', '', '', ''),
(37, 'The process of mobilizing, engaging and maintaining workers to work for an organization is referred to as', 'staffing', 'selection', 'recruitment', 'employment', 'a', 'Answer all Questions', '', '', '', '', ''),
(38, 'Recognized members of the Stock Exchange who buy and sell securities on their own behalf are known as', 'bulls', 'jobbers', 'brokers', 'stags', 'b', 'Answer all Questions', '', '', '', '', ''),
(39, 'Which of the following involved foreign trade?', 'supermarket', 'chain stores', 'departmental stores', 'commodity markets', 'd', 'Answer all Questions', '', '', '', '', ''),
(40, 'Which of the following is a function of employers\' association?', 'undertaking research on behalf of employee', 'promotion of thrift in workers', 'promotion of workers welfare', 'dissemination of information through  sponsored journals', 'd', 'Answer all Questions', '', '', '', '', ''),
(41, 'Which of the following industries is normally located near the source of its raw materials? ', 'foot ware industry', 'cement industry', 'textile industry', 'automobile assembly', 'b', 'Answer all Questions', '', '', '', '', ''),
(42, 'One of the most important functions of marketing is', 'encouraging research activities to meet  needs', 'creating classes of merchants among business men', 'the extension of markets for businesses', 'providing finances to businesses', 'a', 'Answer all Questions', '', '', '', '', ''),
(43, 'Securities on which the buyers are not issued with certificates are called', 'authorized securities', 'inscribed securities', 'bearer securities', 'registered securities', 'b', 'Answer all Questions', '', '', '', '', ''),
(44, 'In product pricing, which of these elements needs more consideration than others?', 'the demand for the product', 'the demography of the buyers of the product', 'the economic conditions in the market', 'the cost of producing the product', 'd', 'Answer all Questions', '', '', '', '', ''),
(45, 'The principal objectives of the Central bank of Nigeria can be classified broadly into', 'bankers\' bank, lender of last resort and issuance of currency', 'service, currency management and financial intermediation', 'banking services, foreign exchange operation and open market operations', 'service, monetary policy and developmental functions', 'd', 'Answer all Questions', '', '', '', '', ''),
(46, 'The letters E and OE stand for', 'errors of exception', 'errors mission expected', 'estimated and order error', 'end of error', 'b', 'Answer all Questions', '', '', '', '', ''),
(47, 'An important issue for consideration in the product e element of the marketing mix is the', 'adequate promotion of the product', 'channel of distribution of the product', 'price of the product', 'planning and development of the product', 'd', 'Answer all Questions', '', '', '', '', ''),
(48, 'A group of companies is a collection of', 'subsidiaries and their holding company', 'firms', 'associates and their holding company', 'industries', 'a', 'Answer all Questions', '', '', '', '', ''),
(49, 'Which of the following is an example of trade association?', 'European Union', 'National Marketing Board', 'Organization of Africa Union', 'National Farmers\' Council', 'd', 'Answer all Questions', '', '', '', '', ''),
(50, 'Which of the following determines the quality of goods that a retailer sells?', 'The mode of contract of sales', 'The type of manufacturer', 'The regulations regarding sales in the Area', 'The location of the Shop', 'b', 'Answer all Questions', '', '', '', '', ''),
(51, 'If the average cost and average revenue of a product are N80.00 and N96.00 respectively and \r\n240 units were produced, what is the profit made?', 'N3,840.00', 'N16.00', 'N38.40', 'N38,400.00', 'a', 'Answer all Questions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `crs`
--

CREATE TABLE `crs` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crs`
--

INSERT INTO `crs` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, '\"Go from your country and your kindred \r\nand your father\'s house to the land that I \r\nwill show you ...\" where was Abram when \r\nthis command was given?  ', 'Haran      ', 'Ur', 'Shechem', 'Bethel', 'a', 'Answer all Questions', '', '', '', '', ''),
(2, 'Adam named his wife eve  because she was', 'the mother of all living', 'the bone of his bones', 'the one that misled him', 'deceived by the serpent', 'a', 'Answer all Questions', '', '', '', '', ''),
(3, 'What was the immediate reaction of Moses \r\nwhen he cast his rod on the ground at \r\nMount Horeb and it became a serpent?  ', 'He caught it immediately', 'He shouted for joy', 'He fled from it ', 'He took, it by the tail.', 'c', 'Answer all Questions', '', '', '', '', ''),
(4, 'The reward for total obedience to the \r\ncommandments of God is', 'material possessions', 'wisdoms', 'life and length of days', 'knowledge', 'c', 'Answer all Questions', '', '', '', '', ''),
(5, 'According to Hosea one of the punishments for the sins of Israel was that', 'the LORD would send famine upon the \r\nland', 'their women would become barren', 'they would eat but would not be \r\nsatisfied', 'they would not receive divine \r\nrevelation.', 'c', 'Answer all Questions', '', '', '', '', ''),
(6, 'After Nebuchadnezzar had destroyed \r\nJerusalem, he took the inhabitants into \r\nexile but left behind the ', 'temple guards', 'poorest people', 'noblemen', 'priests', 'b', 'Answer all Questions', '', '', '', '', ''),
(7, '\" ...I send you to people of Israel, to a nation of rebels ...\"\r\nThe statement above was God\'s message to ', 'Prophet Ezekiel', 'Prophet Isaiah', 'Prophet Jeremiah', 'Prophet Amos.', 'a', 'Answer all Questions', '', '', '', '', ''),
(8, 'According to Amos, the type of famine God said He would send upon the people of Israel was  ', 'hunger for baskets of summer fruits', 'not hearing the word of the LORD', 'thirst for water', 'that of bread.', 'b', 'Answer all Questions', '', '', '', '', ''),
(9, 'Hosea declares that the uprights walk in the ways of the LORD, but transgressors', 'stumble in them', 'flee from them', 'scorn them', 'reject them.', 'a', 'Answer all Questions', '', '', '', '', ''),
(10, 'Elijah knew of the covetous act of Gehazi because ', 'he saw the gifts with him', 'he went with him in spirit', 'it was reported to him', 'he saw him from afar.', 'b', 'Answer all Questions', '', '', '', '', ''),
(11, '\" ...The soul that sins shall die\". The \r\nstatement above by Prophet Ezekiel means that ', 'God will judge the soul of a sinner', 'a sinner shall not escape punishment', 'every person is responsible for his own \r\nsin ', 'the wages of sin is death.', 'c', 'Answer all Questions', '', '', '', '', ''),
(12, 'Daniel was set up to be thrown to the lions by the', 'presidents and satraps of Persia', 'Lords and nobles of Medes', 'counsellors of Nebuchadnezzar', 'advisers of King Xerxes.', 'a', 'Answer all Questions', '', '', '', '', ''),
(13, 'How did Joshua react to the defeat of the Israelites by the men of Ai? ', 'He prayed to God', 'He rent his clothes', 'He consulted the priest', 'He fasted all day.', 'b', 'Answer all Questions', '', '', '', '', ''),
(14, 'The consequence of Hiel\'s building of Jericho was that he', 'lost two of his sons', 'was highly respected by his tribe', 'was killed by Ahab ', 'was made a commander in Ahab\'s \r\narmy.', 'a', 'Answer all Questions', '', '', '', '', ''),
(15, 'God exalted the name of Jesus above every other name in heaven and on earth because ', 'in humility, he counted others better than Himself', 'He humbled Himself to be born in \r\nhuman form and was obedient to death', 'as Son of God, He counted equality with \r\nGod a thing to be grasped', 'Jesus was born in the likeness of man', 'b', 'Answer all Questions', '', '', '', '', ''),
(16, 'According to Peter, when the chief \r\nShepherd would be manifested, the elders \r\nwould obtain the ', 'house of glory', 'crown with stars', 'unfading crown of glory', 'sceptre of authority.', 'c', 'Answer all Questions', '', '', '', '', ''),
(17, 'Paul boasted about the believers in Corinth for their ', 'offering for the saints', 'display of spiritual gifts', 'zeal in prayer', 'maturity in Christ.', 'a', 'Answer all Questions', '', '', '', '', ''),
(18, 'In Paul\'s letter to the Thessalonians, believers were admonished to prepare for the Second Coming of Christ by', 'encouraging idlers to work hard', 'preaching peace and tolerance', 'keeping awake and being sober', 'praying and fasting.', 'c', 'Answer all Questions', '', '', '', '', ''),
(19, 'According to Peter, the genuineness of \r\nChristian faith is tested by', 'fire', 'suffering ', 'temptation', 'trials.', 'd', 'Answer all Questions', '', '', '', '', ''),
(20, 'Paul taught the Romans  that while they were yet enemies of God, they were \r\nreconciled to Him by the ', 'death of Jesus Christ', 'suffering of Jesus Christ', 'resurrection of Jesus Christ', 'ascension of Jesus Christ.', 'a', 'Answer all Questions', '', '', '', '', ''),
(21, 'Paul declared to the believers in Corinth \r\nthat no one can say Jesus is Lord except by  ', 'faith    ', 'the Holy Spirit', 'revelation knowledge', 'grace', 'b', 'Answer all Questions', '', '', '', '', ''),
(22, 'Paul teaches that believers who maintain \r\ngood conduct before governing authorities shall ', 'be shown hospitality', 'be highly honoured', 'receive approval', 'enjoy peace.', 'c', 'Answer all Questions', '', '', '', '', ''),
(23, 'In Colossians, Paul admonished believers \r\nnot to lie to one another because they ', 'had put off the old nature with its \r\npractices', ' had known the truth from the very \r\nbeginning', ' were waiting for the second coming of \r\nChrist', 'were joint heirs with Christ in the \r\nkingdom.', 'a', 'Answer all Questions', '', '', '', '', ''),
(24, '\"...O faithless and perverse generation, how long am I to be with you and bear with \r\nyou...?\" Jesus\' statement above was \r\naddressed to ', 'the Pharisees because of their hypocrisy', 'the Jews because of their unbelief', 'His own people because they did not \r\ngive Him honour', 'His disciples because they could not \r\nheal. \r\n', 'd', 'Answer all Questions', '', '', '', '', ''),
(25, 'The order of the crucifixion events \r\naccording to Luke\'s Gospel is  ', 'mockery lots casting for His dress, \r\nscoffing and crucifixion ', 'lots casting for His dress, mockery, \r\nscoffing and crucifixion', 'crucifixion, scoffing, mockery and lots \r\ncasting for His dress', 'crucifixion, lots casting for His dress, \r\nscoffing and mockery.', 'd', 'Answer all Questions', '', '', '', '', ''),
(26, 'The woman with the flow of blood touched \r\nthe garment of Jesus because ', 'the crowd could not allow her to speak \r\nto Jesus', 'she believe that she would be made \r\nwell ', 'she had heard the reports about Jesus ', 'she had suffered much under many \r\nphysicians.', 'b', 'Answer all Questions', '', '', '', '', ''),
(27, 'What were the two emblems Jesus used \r\nduring the Last supper? ', 'the bread and the wine', 'the unleavened bread and the fruit of \r\nthe vine', 'His blood and His body', 'the bread and the blood of the Lamb. ', 'b', 'Answer all Questions', '', '', '', '', ''),
(28, 'The Macedonians who travelled with Paul \r\nto Ephesus were', 'Demetrius and Alexander', 'Alexander and Gaius', 'Demetrius and Aristarchus', 'Gaius and Aristarchus', 'd', 'Answer all Questions', '', '', '', '', ''),
(29, '\"They have no wine\".\r\nJesus\' immediate response to the \r\nstatement above was   ', '\"...draw some out, and take it to the \r\nsteward of the feast\"', '\" ...O woman, what have you do to with \r\nme? \"', '\"...Do whatever he tells you\"', '\" ...fill the jars with water\"', 'b', 'Answer all Questions', '', '', '', '', ''),
(30, 'In the explanation of the parable of the \r\nweeds, Jesus said that the righteous will ', 'enter into glory with the son of man ', 'live forever in the kingdom of God', 'shine like the sum in theirs is the \r\nkingdom Father ', 'be set aside from all causes of sin', 'c', 'Answer all Questions', '', '', '', '', ''),
(31, 'What did the blind man by the roadside \r\nnear Jericho do on receiving his sight?   ', 'he thanked Jesus for healing him', 'he gave praised to God for making him \r\nwhole', 'he jumped for joy and went away', 'he followed Jesus, glorifying God', 'd', 'Answer all Questions', '', '', '', '', ''),
(32, 'Before the cock crowed, Peter denied Jesus three times. Who was the first person to \r\nrecognize him as one of the disciples?  ', 'one of the rulers', 'the high Priest', 'a maid ', 'a bystander.', 'c', 'Answer all Questions', '', '', '', '', ''),
(33, '\" ...and I will say to my soul, Soul, you have \r\nample goods laid up for many years; take \r\nyour ease, eat, drink, be merry ...\" God\'s \r\nresponse to the statement above was that', 'his soul was required of him', 'his soul should be satisfied with his \r\nincrease ', 'he should lay up more treasures for \r\nhimself', 'the servant should enter into the rest of \r\nthe lord.', 'a', 'Answer all Questions', '', '', '', '', ''),
(34, 'According to the first Epistle of John, to \r\nhave the Son is to have   ', 'the Holy Spirit', 'life', 'salvation', 'the father.', 'b', 'Answer all Questions', '', '', '', '', ''),
(35, ' Peter became frightened as the walked on \r\nthe sea because ', 'of the wind', 'he saw a ghost', 'it was dark and cloudy', 'he doubted Jesus.', 'a', 'Answer all Questions', '', '', '', '', ''),
(36, 'The resolution of the Council at Jerusalem \r\nwas that the Gentiles should abstain from ', 'circumcision, whoremongering, \r\nhomosexuality and falsehood', 'idolatry, unchastity, strangled meat and \r\nblood ', 'homosexuality, idolatry, fornication and \r\nstrangled meat', 'adultery, greed, strangled meat and \r\n  divination.', 'b', 'Answer all Questions', '', '', '', '', ''),
(37, '\"...The earth produces of itself, first the \r\nblade, then the ear, then the full grain in \r\nthe ear...\" The statement above was made \r\nby Jesus in the parable of the  \r\n ', 'Weeds', 'seed growing secretly', 'sower', 'mustard seed.', 'b', 'Answer all Questions', '', '', '', '', ''),
(38, 'The condition Peter gave for a person that \r\nwould replace Judas Iscariot was he must \r\nbe', 'a Galilean', 'a disciple of John the Baptist', 'full of faith', 'a witness to Jesus\' ministry.', 'd', 'Answer all Questions', '', '', '', '', ''),
(39, 'The angel told Zachariah that John the \r\nBaptist would drink no wine nor strong \r\ndrink because he would', 'only eat locusts and wild honey', 'be the forerunner of Jesus', 'baptize sinners who would come too \r\nHim ', ' be filled with the Holy Spirit.', 'd', 'Answer all Questions', '', '', '', '', ''),
(40, 'The signs that God showed to Moses at his call were meant to', 'convince Pharaoh that he was the prophet of God', 'portray him as superior to the Egyptian magicians', 'enable him to perform miracles before Pharaoh', 'convince the people that he has been sent by God', 'd', 'Answer all Questions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `die_alone`
--

CREATE TABLE `die_alone` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `die_alone`
--

INSERT INTO `die_alone` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The sacred Society of the Mende people is the --------', 'the palace', 'Poro cult', 'Kpaa Mende ', 'Sherbrooke ', 'b', 'Questions Based on LET ME DIE ALONE', '', '', '', '', ''),
(2, 'The novelist of the prose is -------- ', 'John Kolosa Kargbo', 'John Thomas', 'William Shakespeare', 'Nancy Caulker', 'a', 'Questions Based on LET ME DIE ALONE', '', '', '', '', ''),
(3, 'Yoko prefers to die because-------', 'Musa and Lamboi wanted the throne', 'Gbanya is dead', 'jeneba is missing', 'she will loos some territories of Mayamba to the colonial masters.', 'd', 'Questions Based on LET ME DIE ALONE', '', '', '', '', ''),
(4, 'The former chiefdom of Mende people after Yoko has many wives?', 'one ', 'twenty ', 'thirty-seven', 'two', 'c', 'Questions Based on LET ME DIE ALONE', '', '', '', '', ''),
(5, 'Jeneba was killed by ------ ', 'Gbanya ', 'jilo and Ndapi', 'Yoko ', 'Musa and Lamboi', 'd', 'Questions Based on LET ME DIE ALONE', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `economics`
--

CREATE TABLE `economics` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `economics`
--

INSERT INTO `economics` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'In capitalist economies, question about what to produce are ultimately answered', 'the same fixed quantity will be supplied no matter the price', 'the quantity supplied is responsive to price', 'an increase in price will result in an increase in the quantity supplied', 'there is a fixed price for the commodity below which no supply will be made', 'a', 'Answer all Questions', '', '', '', '', ''),
(2, 'National income estimates can be used to', 'differentiate between the rich and the poor in a country', 'prepare a country\'s annual budget', 'project the level of a country\'s economic development', 'compare a country\'s growth rate with that of another over a period of time', 'd', 'Answer all Questions', '', '', '', '', ''),
(3, 'Which of the following is a measure of central tendency?', 'median', 'graph', 'percentage', 'variance', 'a', 'Answer all Questions', '', '', '', '', ''),
(4, 'In Nigeria, the bank that can correctly be described as a unit bank is', 'a  the central bank', 'people\'s bank', 'mortgage bank', 'community bank', 'd', 'Answer all Questions', '', '', '', '', ''),
(5, 'The middlemen in the chain of distribution are', 'manufacturers and consumers', 'wholesalers and retailers', 'consumers and wholesales', 'retailers and consumers', 'b', 'Answer all Questions', '', '', '', '', ''),
(6, 'If the arithmetic mean of 1, 2, 6, 6, x, 16 and 18 is 10, find value of x.', '8.5', '22', '8.0', '21', 'd', 'Answer all Questions', '', '', '', '', ''),
(7, 'A consumer\'s scale of preference is an arrangement of his', 'scarce resources in order of importance', 'requirements and how to satisfy them', 'sources of income and their importance', 'needs in order of importance', 'd', 'Answer all Questions', '', '', '', '', ''),
(8, 'If the growth rate of available resources continuously outpaces that of the population, a country will eventually experience', 'maximum population', 'optimum population', 'under-population', 'over-population', 'c', 'Answer all Questions', '', '', '', '', ''),
(9, 'A major problem facing all economies is how to', 'improve trade among nations', 'increase consumption of imported goods', 'allocate scarce resources', 'transform from a developing to a developed economy', 'c', 'Answer all Questions', '', '', '', '', ''),
(10, 'Improved labour efficiency can be measured by', 'a decrease in output-input ratio', 'the constancy in input-output ratio', 'an increase in input-output ratio', 'an increase in output-input ratio', 'd', 'Answer all Questions', '', '', '', '', ''),
(11, 'Economics is regarded as a social science because it', 'adopts the scientific method in the study of human behaviour', 'adopts the scientific method in production', 'is an agent of socialization', 'deals with social problems', 'a', 'Answer all Questions', '', '', '', '', ''),
(12, 'The short-run equilibrium output for a monopolist is determined by the', 'intersection of the marginal cost and marginal revenue curves.', 'minimum point on the average cost curve', 'highest point on the total revenue curve', 'intersection of the average revenue and average cost curves', 'a', 'Answer all Questions', '', '', '', '', ''),
(13, 'The table above shows a demand schedule for eggs.\r\nWhat is the equilibrium price?', 'N100', 'N80', 'N60', 'N110', 'b', 'Answer all Questions', 'eco1.png', '', '', '', ''),
(14, 'An imperfect market exists where', 'the product is homogenous', 'there is a perfect information among the new few buyers and sellers', 'the location of some sellers gives them an advantage over others', 'both buyers and sellers have free entry into and free exit from the market', 'c', 'Answer all Questions', '', '', '', '', ''),
(15, 'The economic policy of deregulation is aimed at encouraging', 'a competitive market structure', 'a monopolistic market structure', 'a duopolistic market structure', 'an oligopolistic market structure', 'a', 'Answer all Questions', '', '', '', '', ''),
(16, 'Which of the following is an example of a fixed cost?', 'fuel cost', 'rent on building', 'electricity bill', 'transportation cost', 'b', 'Answer all Questions', '', '', '', '', ''),
(17, 'If government fixes price below the equilibrium price, what effect will it have on demand?', 'quantity demanded and supplied will be equal', 'quantity supplied will be greater than quantity demanded', 'quantity demanded will decrease', 'quantity demanded will increase', 'd', 'Answer all Questions', '', '', '', '', ''),
(18, 'To facilitate the exportation of crude oil from Nigeria, special', 'railway lines were constructed to connect the major oil wells to the ports', 'roads were built to connect the major oil wells to the ports', 'airstrips were constructed for jets to evacuate the oil', 'pipelines were laid to connect the major oil wells to the ports', 'd', 'Answer all Questions', '', '', '', '', ''),
(19, 'The raising of funds by selling stocks to the public is called', 'stock financing', 'equity financing', 'loan financing', 'debt financing', 'b', 'Answer all Questions', '', '', '', '', ''),
(20, 'A disadvantage of concentrating industries in an area is that it could', 'bring about diseconomies of scale', 'lead to collusion among the firms', 'increase the cost of production', 'result in environmental pollution', 'd', 'Answer all Questions', '', '', '', '', ''),
(21, 'The losses suffered by a sole proprietor are', 'not limited to the amount invested', 'limited to the amount invested', 'usually less than that amount invested', 'usually equal to the amount invested', 'a', 'Answer all Questions', '', '', '', '', ''),
(22, 'The capital market is a market for trading of financing assets such as', 'treasury bills', 'commercial papers', 'bankers\' acceptances', 'long-term securities', 'd', 'Answer all Questions', '', '', '', '', ''),
(23, 'When two variables are positively related, the graph of the relationship', 'is a downward-sloping curve', 'has a negative intercept', 'is a straight line', 'is an upward-sloping curve', 'd', 'Answer all Questions', '', '', '', '', ''),
(24, 'For an inferior good, a decrease in real income will lead to', ' a lower equilibrium price', 'a change in quantity demanded', 'an outward shift of the demanded curve', 'an inward shift of the demand curve', 'c', 'Answer all Questions', '', '', '', '', ''),
(25, ' If the country is currently producing at point Y, it can increase production of producer goods by', 'W', 'X', 'Z', 'V', 'a', 'Answer all Questions', 'eco2.png', '', '', '', ''),
(26, 'An improvement in technology will enable the country produce at', 'x', 'v', 'z', 'w', 'c', 'Answer all Questions', 'eco2.png', '', '', '', ''),
(27, 'The price of a good rises from N5 to N8 and the quantity demanded falls from 200 to 190 units.  \r\nOver this price range, the demand curve is', ' perfectly in elastic', ' fairly in elastic', ' perfectly e lastic', ' fairly e lastic ', 'b', 'Answer all Questions', '', '', '', '', ''),
(28, 'In a planned economy, the emphasis is on', 'public ownership and control', 'price and competition', ' individual choices and decisions', 'private ownership and control', 'a', 'Answer all Questions', '', '', '', '', ''),
(29, 'In the table, the price of commodity y is N2 and that of x is N1 while the individual has an income \r\nof N12.  Determine the combination of the two commodities the individual should consume to maximize \r\nhis utility', '6y and 4x ', '3y and 6x', '5y and 5x', '3y and 3x', 'b', 'Answer all Questions', 'eco3.png', '', '', '', ''),
(30, 'If there is an increase in demand without a corresponding increase in supply, there will be a  ', 'rise in price', 'shift in demand curve to the left', 'fall in price', ' shift in supply curve to the right', 'a', 'Answer all Questions', '', '', '', '', ''),
(31, 'The world population is not equally distributed over the globe. Of the 10 most populous countries,_______ are in Asia.', '6', '4', '2', '1', 'a', 'Answer all Questions', '', '', '', '', ''),
(32, 'Some of the key indicators of under development in a country are', 'poverty, low level of literacy and low income', 'low level of illiteracy, low income and poverty', 'poverty, high level of literacy and low income', 'poverty, low income and low unemployment', 'a', 'Answer all Questions', '', '', '', '', ''),
(33, 'The median of an odd numbered set of scores is the', 'highest value of the set', 'middle value of the set', 'arithmetic mean of the set', 'most frequently occurring scoreBusiness', 'b', 'Answer all Questions', '', '', '', '', ''),
(34, 'External finance for a limited liability company is mainly sourced through', 'trade credits', 'bank loans', 'the issuing of shares', 'the leasing of equipment', 'c', 'Answer all Questions', '', '', '', '', ''),
(35, 'A scientific approach in economic analysis entails', 'both inductive and deductive methods', 'both inductive and normative methods', 'a deductive method only', 'a normative method only', 'a', 'Answer all Questions', '', '', '', '', ''),
(36, 'Which of the following yields more revenue to Nigeria?', 'value added tax', 'royalties', 'indirect tax', 'direct tax', 'd', 'Answer all Questions', '', '', '', '', ''),
(37, 'In the pie chart above, the percentage for men is equivalent to', '90 degrees', '126 degrees', '72 degrees', '144 degrees', 'a', 'Answer all Questions', 'eco4.png', '', '', '', ''),
(38, 'A woman has N5000.00 with which to buy a cloth costing N2200.00 and an wrist watch costing N3500.00.  If he buys the wrist watch, his opportunity cost is', 'N1300.00', 'the wrist watch', 'the cloth', 'N2200.00', 'c', 'Answer all Questions', '', '', '', '', ''),
(39, 'In the diagram above, the marginal rate of substitution of X for Y for a movement from S to T is', '13:3', '1:5', '18:4', '5:1', 'a', 'Answer all Questions', 'eco5.png', '', '', '', ''),
(40, 'Import substitution aims at', 'substituting agricultural products with industrial ones', 'substituting imports with agricultural exports', 'the diversification of industries', 'improving the balance of payments', 'd', 'Answer all Questions', '', '', '', '', ''),
(41, 'The elasticity of supply of perishable goods is', 'inelastic', 'unitary', 'zero', 'elastic', 'a', 'Answer all Questions', '', '', '', '', ''),
(42, 'ECOWAS has taken a giant step towards economic integration by', 'presenting a united front against foreign economic exploiters ', 'introducing a common currency for travellers', 'holding frequent meetings at various state capitals', 'increasing economic stability among member states.', 'b', 'Answer all Questions', '', '', '', '', ''),
(43, 'One of the major factors militating against industrialization in Nigeria is the', ' inadequacy of infrastructural facilities ', 'absence of government participation', 'frequent breakdown of equipment ', 'failure to get foreign partners and supporters.', 'a', 'Answer all Questions', '', '', '', '', ''),
(44, 'The types, sources and uses of government income are mainly concerned with', 'public expenditure ', 'public revenue', 'public budget', 'public finance.', 'd', 'Answer all Questions', '', '', '', '', ''),
(45, 'The present privatization policy in Nigeria is aimed at', 'reducing income inequality', 'reducing the prices of goods and services ', 'poverty alleviation', ' increasing efficiency in production. ', 'd', 'Answer all Questions', '', '', '', '', ''),
(46, 'One of the major problems arising from the localization of industries is ', ' high prices of output ', 'the exportation of output ', 'the scarcity of foreign exchange', 'structural unemployment.', 'd', 'Answer all Questions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `eng1`
--

CREATE TABLE `eng1` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng1`
--

INSERT INTO `eng1` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`) VALUES
(1, 'According to the passage, \"the moralist idea\" is that', 'people should accept a point of view only when they are convinced.', 'smoking is not good but a little alcohol may be permitted. ', 'the smoking of cigarettes is bad and unacceptable.', 'it is typically African not to smoke cigarettes', 'c', ' - Read the passage carefully and use it to answer questions'),
(2, 'It can be concluded from the passage that  morality religion and economy are', 'somewhat interconnected', 'clearly interconnected.', 'certainly unrelated', 'certainly different', 'a', ' - Read the passage carefully and use it to answer questions'),
(3, 'Which of the following statements is true according to the passage?', 'Everyone ignores the moralist view on drinking and smoking', 'Total abstinence from drinking and smoking is a religious obligation. ', ' People who drink or smoke surely die of cancer.', 'Smoking and drinking may have positive effects on the economy.', 'd', ' - Read the passage carefully and use it to answer questions'),
(4, 'The view expressed by the writer in the last paragraph is that', 'more people appear to take to drinking and smoking.', 'the number of alcoholics and smokers is certainly increasing.', 'sales of alcohol and tobacco products have improved tremendously.', 'more people now abstain from drinking and smoking. ', 'a', ' - Read the passage carefully and use it to answer questions'),
(5, 'The positions maintained by the moralist and the economist can be described as being', 'very passionate', 'quite indifferent', 'at variance', 'very agreeable', 'c', ' - Read the passage carefully and use it to answer questions');

-- --------------------------------------------------------

--
-- Table structure for table `eng2`
--

CREATE TABLE `eng2` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng2`
--

INSERT INTO `eng2` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`) VALUES
(1, 'Which of the following statements is true according to the passage?', 'Man poses the greatest threat to Nature', 'Man kills animals only when he can afford to do so.', 'Man cannot spare those animals that eat his kind.', 'Man eats all categories of animals.', 'a', ' - Read the passage carefully and use it to answer questions'),
(2, 'The sentence, \'There will be twice as many of us before most of us are dead\' means', 'the population growth rate will double before our death.', 'mankind is fast spreading across the earth. ', 'some increase in human and animal population growth rates.', 'many of us will die as a result of population explosion.', 'a', ' - Read the passage carefully and use it to answer questions'),
(3, 'The expression when man evolved a conscience means when', 'man acquired new habits', 'man developed an awareness of right and wrong.', 'man became a critical creature', 'man\'s intellect improved tremendously.', 'b', ' - Read the passage carefully and use it to answer questions'),
(4, 'From the passage, the attitude of the writer can be described as ', 'optimistic', 'indifferent', 'pessimistic', 'partial', 'a', ' - Read the passage carefully and use it to answer questions'),
(5, 'The basic causes of the elimination of certain animals from the earth include', 'man\'s penchant for meat and the sale of animals for meat and hides. ', ' man\'s decision to live in cities and the development of large farmlands. \r\n', 'a deliberate battle against Nature and the quest for leopard skin.', 'extensive killing of animals and the fast disappearance of their favourable habitats.', 'd', ' - Read the passage carefully and use it to answer questions');

-- --------------------------------------------------------

--
-- Table structure for table `eng3`
--

CREATE TABLE `eng3` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng3`
--

INSERT INTO `eng3` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`) VALUES
(1, 'Where are the rich getting richer and the poor poorer?', 'nearly all places in the world', 'nearly all developing countries', 'developing countries with modern sectors', 'developing countries with non-modern sectors', 'a', ' - Read the passage carefully and use it to answer questions'),
(2, 'The  poor  in  developing  countries', 'don\'t  want  to  work', 'simply  cannot  work', 'have no opportunity to work', 'work very hard', 'c', ' - Read the passage carefully and use it to answer questions'),
(3, 'Migration to the city among villages is caused by', 'attraction of the city', 'lack of productivity in the villages', 'inadequate land for cultivation', 'inadequate job opportunities in the village', 'd', ' - Read the passage carefully and use it to answer questions'),
(4, 'The  city  offer  the  migrants', 'no  housing', 'plenty  of  job  opportunities', 'enough accommodation', 'greater chances of employment', 'd', ' - Read the passage carefully and use it to answer questions'),
(5, 'By \"work their way out of their situation\"   the writer means:', 'walk from one village to another', 'migrate from city to villages', 'produce enough food for themselves', 'work for high rewards', 'd', ' - Read the passage carefully and use it to answer questions');

-- --------------------------------------------------------

--
-- Table structure for table `english_passage`
--

CREATE TABLE `english_passage` (
  `id` int(2) NOT NULL,
  `passage` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `english_passage`
--

INSERT INTO `english_passage` (`id`, `passage`) VALUES
(1, 'Attitudes  toward  the  smoking  of  cigarettes and  the consumption of alcohol may be used to illustrate  typical  African  ethics.  Apart  from  the fact  that smoking has now been  linked with  the lung  cancer  disease,  the  African  moralist  has always  regarded  smoking  as  an indication  of moral  degradation.  \r\nA  number  of  people  have accepted  the  moralist  idea  on  smoking.  Some have  refrained  from  smoking,  and  those  who could  influence  others,  such  as  parents  and religious leaders, have also exerted their influence to  prevent  others  from  smoking.  \r\nOn  the  other hand,  a  good  many  people  have  remained indifferent  to  the  moralist  view  and  have continued  to  smoke.  The  same  argument  has been applied to the consumption of alcohol. The African  moralist,  basing  his  judgement  on  the behaviour of a few alcoholics, tends to regard the habit of taking alcohol as a sign of wretchedness. The  moralist  holds  the  view  that  anybody  who forms  the  habit of  consuming alcohol  will  never do well in life. While this may be true in respect of a  few  people  in  the  society,  the  fear  of  the moralist  has  not  been  justified.  \r\nHowever, the economist  is  primarily  interested  in  the  habit  of smoking and the consumption of alcohol in so far as they give satisfaction to smokers and drinkers and  so  generate  supply  of  and  demand  for tobacco and alcohol. The economist is interested in  knowing  how  many packets  of  cigarettes  are consumed and to what extent an increase or fall in  consumption  could  affect  production  that  is, supply.  Similarly,  he  is  interested  in  how  much beer is consumed and how the supply of beer will adjust  to  the  demand  for  it.  He  examines  the habits  and  the  pressures  which  can  lead  to  the readjustment  of  wants  and  the  reallocation  of resources to cover the wants. \r\nSome  moral  principles  associated  with religion  tend  to  lead  on  to  economic  problems. Followers of certain religions are expected not to consume  pork,  take  alcohol  or  smoke  tobacco. Devotees of some religious groups, on the other hand, can eat pork while others are expected to abstain  from  alcohol  and  smoking.  Strict observance of these moral rules could cripple the breweries,  the  cigarette  factories  and  some businesses;  however,  there  seems  to  be  a growing  number  of  alcohol  consumers  and cigarette smokers - a development which should be of interest to the   economist.\r\n'),
(2, 'When  man  evolved  a  conscience,  his  basic relationship  with  the  other  animals  began  to change. Until then, they were broadly divided into those  which ate him  when  they  got  the  chance, those which he ate when he got the chance, and a third group which competed with him for food, or was otherwise a nuisance to him in the business of keeping alive.  In the primitive situation, man was, therefore, basically  against  Nature  but,  as  the  battle  was progressively  won,  conscience  crept  in;  the  awareness of responsibility, and a failure to meet it,  produced  feelings  of  guilt.  Those  who  live  in cities and need no longer do battle against Nature are nowadays most actively for Nature. At this time, something like a thousand kinds of animals (vertebrate animals) can be said to be in danger of extinction. A few of them have been reduced to this precarious position by extensive killing but the majority are disappearing only as fast as the particular kind of country they need for existence is itself disappearing: and all this at the hands of man, as often as not by mistake.  There  are  three  species  of  turtles  whose future  survival  is  menaced  by  the  demand  for turtle  soup,  which  would  hardly  justify  the examination  of  a  giant  reptile  whose  family  has existed  for  200  million  years.  Leopards  are  in jeopardy because of the fashion for their skins. As they get rarer, the prices rise and, as leopard skin coasts  become  more  expensive,  the  demand increases. No species can long survive the price of N60,000  which  a  half-grown  baby  leopard  now carries  on  its  skin.  And  crocodiles,  the  longest surviving  reptiles,  are  now  dwindling  alarmingly as  a  result  of  the  fashion  in  crocodile  skin  for ladies\' handbags and men\'s shoes.    The  human  population  explosion  spreads mankind across the land surfaces of the earth at an alarming rate. There will be twice as many of us before most of us are dead. Does this mean no room  for  wild  animals?  Of  course  not.  With ingenuity and forethought, a place can be kept for them.  To  destroy  their  habitat  is as unnecessary as  it would be to pull down a great cathedral  in order to grow potatoes on the sites. A campaign to save what remains is the concern of a new kind of Noah\'s Ark - the World Wildlife Fund. It does not believe that all is lost.  Adapted from Peter Scott\'s article in Sunday Times.'),
(3, 'In many places in the world today, the poor are getting poorer while the rich are getting richer, and the programmes of development planning and foreign aid appear to be unable to reverse this trend. Nearly all  the  developing  countries  have  a  modern  sector,  where  the  patterns  of living  and  working  are similar to those in developed countries. But they also have a non-modern sector, where the patterns of living and working are not only unsatisfactory, but in many cases are even getting worse. \r\nWhat is typical condition  of the poor in  developing  countries?. \"Their  work opportunities\" are so limited that they  cannot  work their  way  out  of their  situation. They  are  under-employed,  or totally unemployed; when they do find occasional work their productivity is extremely low. Some of them have land, but often too little land. Many have no land, and no prospect of ever getting any. There is no hope for them in the rural areas, and so they drift into the big cities. But there is no work for them in the big  cities  either and  of  course  no  housing.  All the same, they  flock into  cities because their chances  of  finding  some  work  appears  to  be  greater  there  than  in  the  villages,  where  they  are  nil. \r\nRural  unemployment,  then,  produces  mass-migration  into  the  cities,  rural  unemployment  becomes urban unemployment.\r\nThe problem can be stated quite simply: what can be done to promote economic growth outside the big cities, in the small towns and villages, which still contains 80 to 90% of the total population. The primary need is jobs, literally millions of jobs\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `engpass`
--

CREATE TABLE `engpass` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `engpass`
--

INSERT INTO `engpass` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`) VALUES
(9, 'Johnson is a stubborn man; he will never ________ his words.', 'chew', 'spit', 'eat', 'bite', 'a', 'Choose the option that best fills the gap(s)'),
(10, 'The class ________ more girls than boys this session.', 'comprised of', 'comprises of', 'comprise', 'comprises', 'c', 'Choose the option that best fills the gap(s)'),
(11, 'Joseph\'s now a ________ student but it took him years to _______', 'matured/mature', 'mature/mature', 'mature/matured', 'matured/matured', 'a', 'Choose the option that best fills the gap(s)'),
(12, 'The rebels will soon fight back, we have been informed ________ their ________', 'of/predicament', 'about/indulgence', 'On/rearmament', 'as for/ advancement', 'c', 'Choose the option that best fills the gap(s)'),
(13, 'Kindly ________ me your book because my friend has ________ mine', 'borrow/borrowed', 'borrow/lent', 'lend/lent', 'lend/borrowed', 'd', 'Choose the option that best fills the gap(s)'),
(14, 'Two young boys have been caught with parts of the stolen machine but ________ admitted stealing it', 'neither of them has', 'neither of them have', 'none of them has', 'none of them have', 'a', 'Choose the option that best fills the gap(s)'),
(15, 'The adventurers ran into many ________ in the forest.', 'dear', 'dears', 'deers', 'deer', 'd', 'Choose the option that best fills the gap(s)'),
(19, 'The highly appreciative audience clapped ________ hands and showered ________ on the \r\nlecturer.', 'their/encomiums', 'its/encomiums', 'their/invectives', 'its/invectives', 'a', 'Choose the option that best fills the gap(s)'),
(20, 'He is ________ Kaduna ________ an official assignment. ', 'in/on', 'at/in', 'at/for', 'for/in', 'a', 'Choose the option that best fills the gap(s)'),
(21, 'Didn\'t ________ draw your attention to the entry requirements?', 'anyone  ', 'somebody  ', 'someone  ', 'everyone', 'a', 'Choose the option that best fills the gap(s)'),
(22, 'These ________ must have ________ the world Bank Officials.', 'analyses/attract', 'analyses/attracted', 'analysis/attract', 'analysis/attracted', 'b', 'Choose the option that best fills the gap(s)'),
(23, 'The members elected Baba ________ of the committee.', 'chairman', 'their chairman', 'to become chairman', 'to be a chairman', 'a', 'Choose the option that best fills the gap(s)'),
(24, 'The new Inspector of Police decided that culprits should be \"brought to book\"', 'should have their names recorded in a book', 'should be   booked', 'should be made to answer for their conduct', 'should be brought before him to show whether they could read or not', 'c', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(26, 'In their desire to impress their friends and relatives, many young workers \"bite off  more than they can chew, \" in terms of financial obligations', 'have more money than sense', 'spend too much money on food', 'care too much for  their relatives', 'take on more responsibility than they can afford', 'd', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(27, 'The preacher has \"made good his promise\" to visit some of his converts', 'fulfilled', 'improved on', 'seen to', 'accepted', 'a', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(28, 'The boys knew that a storm was \"imminent\"', 'impending', 'encroaching', 'possible', 'threatening', 'a', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(29, 'The leader has the \"unstinting\" support of his party.', 'cautious', 'uninspiring', 'unsparing', 'laudable', 'c', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(30, 'The \"essence\" of governance is to seek the good and well-being of the majority of the people.', 'characteristic', 'importance', 'secret', 'goal', 'd', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(31, 'The carpenter built a \"commodious\" wardrobe.', 'wide', 'gigantic', 'small', 'spacious', 'd', 'Choose the option that is nearest in meaning to the word(s) or phrase(s)in quote'),
(33, 'typist', 'refuse (noun)', 'superb', 'propose', ' rebel (verb)', 'a', 'Choose the option that has the same stress pattern as the \r\ngiven word'),
(34, 'cement', 'perfect (adjective)', 'include', 'interest', ' employ (noun)', 'b', 'Choose the option that has the same stress pattern as the \r\ngiven word'),
(35, 'markEt', 'mortgage', 'bachelor', 'get', 'enter', 'a', 'Choose the option \r\nthat has the same vowel sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(36, ' cOLOnel', 'golden', 'girl', 'colony', 'goal', 'b', 'Choose the option \r\nthat has the same vowel sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(37, 'tEnd', 'cancel', 'jeopardy', 'turned', 'earned', 'b', 'Choose the option \r\nthat has the same vowel sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(38, 'The President SPOKE to the press', 'Did the President write to the press?', 'Did the President speak to the press?', 'Who spoke to the press? ', 'Are these the pressmen that the President spoke?', 'a', 'The word in capital \r\nletter has the emphatic stress. Choose the option to which the sentence relates'),
(39, 'My MOTHER served rice and fresh fish stew for dinner. ', 'Did your mother serve rice and fresh fish stew for lunch? ', 'Who served rice and fresh fish stew for dinner?', 'What kind of meal did your mother serve for dinner? ', 'What kind of stew did your mother serve for dinner? ', 'b', 'The word in capital \r\nletter has the emphatic stress. Choose the option to which the sentence relates'),
(40, 'Chalet ', 'chairman', 'college', 'champagne', 'chemical', 'c', 'Choose the option \r\nthat has the same consonant sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(41, 'teeTH', 'taught', 'tank', 'though', 'thought', 'd', 'Choose the option \r\nthat has the same consonant sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(42, 'coNcrete', 'anxious', 'concern', 'consider', 'attend', 'a', 'Choose the option \r\nthat has the same consonant sound as the one \r\nrepresented by the CAPITAL Letter(s)'),
(44, 'The lecture seemed \"interminable\"', 'unending', 'boring', 'interesting', 'brief', 'd', 'Choose the option opposite in meaning to the word(s) or phrase in QUOTE'),
(45, 'Had I known about their plan much earlier, I would have \"nipped\" it in the bud.', 'stopped it', 'initiated it', 'squashed it', 'promoted it', 'b', 'Choose the option opposite in meaning to the word(s) or phrase in QUOTE'),
(46, 'What a \"harmless\" thought he has!', 'pernicious', 'pertinent', 'perfect', 'pleasant', 'a', 'Choose the option opposite in meaning to the word(s) or phrase in QUOTE'),
(47, 'The town was all \"agog\" at his unexpected return.', 'on fire', 'excited', 'unexcited', 'surprised', 'c', 'Choose the option opposite in meaning to the word(s) or phrase in QUOTE'),
(48, 'The teacher taught the \"rudiments\" of Chemistry to the first grade.', 'elements', 'theories', 'fundamentals', 'basics', 'b', 'Choose the option opposite in meaning to the word(s) or phrase in QUOTE'),
(49, 'If he went to London, he would see the \r\nQueen. ', 'He did not go to London and did not see the Queen.', 'He would like to see the Queen when he goes to London.', 'When he goes to London, he will see the Queen', 'He did not see the Queen when he went \r\nto London.', 'a', 'Select the option \r\nthat best explains the information conveyed in \r\nthe sentence.'),
(50, 'Ngozi has always considered her father to be an impassioned man.', 'Her father is a very strict man', 'Her father is a very lively man. ', 'Her father is an emotional man', 'Her father is a disciplined man.', 'c', 'Select the option \r\nthat best explains the information conveyed in \r\nthe sentence.'),
(51, 'The manager paid us in hard currency', 'We were paid in a strong and stable  \r\n      currency. ', ' We were paid in dollars and pound  \r\n      sterling', 'We were paid in new notes.', 'We were paid in foreign currency.', 'a', 'Select the option \r\nthat best explains the information conveyed in \r\nthe sentence.'),
(52, 'The elders rebuked Olu for taking issue with his principal.', 'Olu was scolded for acting in collusion \r\nwith his principal. ', 'Olu was reprimanded for arguing with  \r\n      his principal.', 'Olu was blamed for issuing a statement \r\ndenying his principal. \r\n', ' Olu was cautioned for shouting at his  \r\n      principal.', 'b', 'Select the option \r\nthat best explains the information conveyed in \r\nthe sentence.'),
(53, 'In spite of his humble beginning, Audu now throws his weight around.', 'His noble birth notwithstanding, Audu is a corrupt man.', 'From his poor background, Audu is now a rich man. \r\n', 'Despite his obvious poverty, Audu is a proud man.', 'Audu is arrogant despite his simple upbringing.', 'd', 'Select the option \r\nthat best explains the information conveyed in the sentence.'),
(54, 'Jankoli was dressed in an odd \"assortment\" of clothes', 'homogeneity', 'mélange', 'sameness ', 'avalanche', 'b', ' Choose the option nearest in meaning to the word or phrase in quotation');

-- --------------------------------------------------------

--
-- Table structure for table `fences`
--

CREATE TABLE `fences` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fences`
--

INSERT INTO `fences` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'Troy refused to sign his son\'s form due to', 'his behaviour', 'his passed experience', 'his wife', 'his family background', 'b', 'Questions Based on FENCES', '', '', '', '', ''),
(2, 'The dramatist of the play is ', 'Osborne John James ', 'August Wilson', 'Thomas Maxson', 'Dalton Smith', 'b', 'Questions Based on FENCES', '', '', '', '', ''),
(3, 'Troy was robbed of his baseball career because of his', 'color ', 'race ', 'family ', 'belief', 'b', 'Questions Based on FENCES', '', '', '', '', ''),
(4, 'Rose Maxson wants a fence to be built around the house to', 'keep Cory inside ', 'stop Alberta from coming in', 'to keep her family safe ', 'make Troy and Cory friendly', 'c', 'Questions Based on FENCES', '', '', '', '', ''),
(5, 'The theme of betrayal in the play centres on the following character.', 'Troy Maxson', 'Gabriel Maxson', 'Cory Maxson', 'Rose Maxson', 'a', 'Questions Based on FENCES', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `good_morrow`
--

CREATE TABLE `good_morrow` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `good_morrow`
--

INSERT INTO `good_morrow` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The above poem talks about', 'love ', 'trust ', 'betrayal ', 'deceit', 'a', 'Questions Based on THE GOOD MORROW\r\n\r\nMy face in thine eyes appears\r\nAnd true plain heart faces rest\r\nWhere can find two better hemispheres\r\nWithout sharp north declining west', '', '', '', '', ''),
(2, 'The rhyming scheme of the above poem is', 'bbaa ', 'abab ', 'abab ', 'abcd', 'b', 'Questions Based on THE GOOD MORROW\r\n\r\nMy face in thine eyes appears\r\nAnd true plain heart faces rest\r\nWhere can find two better hemispheres\r\nWithout sharp north declining west', '', '', '', '', ''),
(3, '\"Hemispheres \" means ', 'The planet', 'half of the earth ', 'north only', 'the sea area of the earth', 'b', 'Questions Based on THE GOOD MORROW\r\n\r\nMy face in thine eyes appears\r\nAnd true plain heart faces rest\r\nWhere can find two better hemispheres\r\nWithout sharp north declining west', '', '', '', '', ''),
(4, 'The poet of the above poem is', 'John Donne', 'Chibuike Onu', 'Dylon Thomas', 'Dalton Smith', 'a', 'Questions Based on THE GOOD MORROW\r\n\r\nMy face in thine eyes appears\r\nAnd true plain heart faces rest\r\nWhere can find two better hemispheres\r\nWithout sharp north declining west', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `government`
--

CREATE TABLE `government` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `instruction` longtext NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `government`
--

INSERT INTO `government` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `qimage`, `instruction`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The delineation of constituencies is a \r\nmajor duty of the ', ' Electoral Commission', ' Boundary Commission', 'National Assembly ', ' Political Parties ', 'a', '', 'Answer all Questions', '', '', '', ''),
(2, ' To qualify for absorption into the \r\nadministrative cadre of the civil service in \r\nNigeria, an applicant must be', 'a senior civil servant', 'specifically trained in public \r\nadministration', 'a holder of a first university degree ', 'knowledgeable in civil service rules', 'c', '', 'Answer all Questions', '', '', '', ''),
(3, 'The principle of checks and balances \r\nreinforces separation of powers in order \r\nto ', 'make the legislature more powerful', ' prevent the emergence of \r\ndictatorship', 'protect the powers of the executive', 'prevent an unconstitutional change \r\nof Government ', 'b', '', 'Answer all Questions', '', '', '', ''),
(4, ' Proportional  representation  is  a \r\nsystem of  allocating  seats  in  the  legislature \r\nbased on', 'contribution to the national economy', 'total votes in an election', 'an area\'s involvement in politics', 'gender participation in politics', 'b', '', 'Answer all Questions', '', '', '', ''),
(5, ' Delegated legislation becomes \r\nunavoidable when ', ' issues under consideration are \r\n  technical', 'legislators have to proceed on a \r\nrecess ', ' legislators cannot reach a consensus', ' issues under consideration are \r\npersonal', 'a', '', 'Answer all Questions', '', '', '', ''),
(6, 'The standing committee of a legislature is one', 'whose members stand while  deliberating', 'that has statutory responsibilities', 'that performs ad hoc function', 'that has all legislators as members', 'c', '', 'Answer all Questions', '', '', '', ''),
(7, 'Where the constitution is supreme, unconstitutional acts of the executive and the legislature can be checked by the courts through', 'recall', 'judicial review', 'vote of no confidence', 'impeachment', 'b', '', 'Answer all Questions', '', '', '', ''),
(8, 'A major issue that distinguishes pressure \r\ngroups from political parties is', 'the objective', 'ideology', 'membership drive', 'the voting pattern', 'a', '', 'Answer all Questions', '', '', '', ''),
(9, 'Citizenship in a modern state expresses \r\nthe status of a person who possesses', 'exclusive economic rights', 'full political rights', 'some religious rights', 'social rights only', 'b', '', 'Answer all Questions', '', '', '', ''),
(10, 'The structure of the civil service is based on ', 'hierarchical organization', 'lateral organization', 'merit system', 'patronage system', 'a', '', 'Answer all Questions', '', '', '', ''),
(11, 'Oligarchy is a form of government which', 'protects the interest of the common \r\npeople', 'disregards the views of the minority', 'enhances the interest of the ruling \r\nfew ', 'enhances the electoral chances of \r\nthe majority', 'c', '', 'Answer all Questions', '', '', '', ''),
(12, 'A common feature of, a multi-party system is that government is formed by ', 'a coalition of political parties', 'the party with the highest votes', 'the major political party', 'all the registered political parties', 'a', '', 'Answer all Questions', '', '', '', ''),
(13, 'The main legislative body in Nigeria between 1966 and 1975 was the', 'Supreme Military Ruling Council', 'Armed\' Forces Ruling Council', 'Provisional Ruling Council', 'National Security Council', 'a', '', 'Answer all Questions', '', '', '', ''),
(14, 'The absence of the rule of law in government will bring about', 'corrupt practices', 'political apathy', 'treasonable offences', 'human right abuse', 'd', '', 'Answer all Questions', '', '', '', ''),
(15, 'One major factor that differentiates the presidential from the parliamentary system is', 'judicial independence', 'party system', 'separation of powers', 'passage of bills', 'c', '', 'Answer all Questions', '', '', '', ''),
(16, 'Who among the following served as Secretary-General of OPEC?', 'Aret Adams', 'Rilwanu Lukman', 'Jibril Aminu', 'Dan Etete', 'b', '', 'Answer all Questions', '', '', '', ''),
(17, 'Which of these international finance agencies is Nigeria a member?', 'The Paris Club', 'The London Club', 'The International Monetary Fund', 'The Infrastructure Development Fund', 'c', '', 'Answer all Questions', '', '', '', ''),
(18, 'Nigerian\'s active role in the liberation of some countries in Southern Africa earned her', 'the status of a frontline state', 'recognition as the giant of Africa', 'the chairmanship of the Eminent Persons Group', 'membership of SADC', 'a', '', 'Answer all Questions', '', '', '', ''),
(19, 'The impact of the Commonwealth of Nations is felt most in the area of', 'cultural cooperation', 'military cooperation', 'economic cooperation', 'diplomatic cooperation', 'a', '', 'Answer all Questions', '', '', '', ''),
(20, 'Which of the following is a founding member of OPEC?', 'Indonesia', 'Algeria', 'Nigeria', 'Venezuela', 'd', '', 'Answer all Questions', '', '', '', ''),
(21, 'Centralization of power is the basic \r\nfeature of', 'a confederation', 'a unitary government', 'federalism', 'a presidential system', 'b', '', 'Answer all Questions', '', '', '', ''),
(22, ' A major consequence of proportional \r\nrepresentation is that it ', 'encourages the proliferation of \r\nparties ', 'discourages voting along ethnic lines', 'reduces the chances of political \r\n  instability', 'favours the development of a two-\r\nparty system', 'a', '', 'Answer all Questions', '', '', '', ''),
(23, 'Communism is a system which \r\nrecognizes', 'the existence of the state', 'the existence of the individual', ' the ability of the individual', 'class stratification', 'b', '', 'Answer all Questions', '', '', '', ''),
(24, 'The application of the principle of \r\nseparation of powers seems \r\nimpracticable because power is', ' fused', 'separated', 'delegated ', ' centralized', 'a', '', 'Answer all Questions', '', '', '', ''),
(25, 'One major disadvantage of public opinion \r\nis that', 'leaders are unnecessarily criticized', 'gossip and rumours thrive', 'a vocal minority claims to represent \r\nthe majority', 'the critics of government policies are \r\nalways harassed', 'c', '', 'Answer all Questions', '', '', '', ''),
(26, 'Under the 1999 Constitution of Nigeria, the power to create local governments is vested in the', 'national assembly', 'state assembly', 'office of the deputy governor', 'presidency', 'b', '', 'Answer all Questions', '', '', '', ''),
(27, 'The central points of capitalism as expounded by Karl Marx is that', 'capitalists\' profit is the surplus value obtained from workers\' labour', 'capitalists shall always increase  workers\' earning capacity through wages', 'capitalists shall always readily consent to workers\' welfare demands', 'workers are inherently incapable of being owners of their labour', 'a', '', 'Answer all Questions', '', '', '', ''),
(28, 'A constitution that requires a plebiscite or a referendum to be amended is', 'written', 'rigid', 'unwritten', 'flexible', 'a', '', 'Answer all Questions', '', '', '', ''),
(29, 'In the legislative process, a bill is a', 'motion accepted for debate', 'proposal before the legislature', 'motion rejected after debate', 'law passed by the legislature', 'b', '', 'Answer all Questions', '', '', '', ''),
(30, 'One of the advantages of a bicameral over a unicameral legislature is that it', 'takes less time for bills to be passed', 'promotes social equality', 'prevents the passage of illconsidered bills', 'is cheap to maintain', 'c', '', 'Answer all Questions', '', '', '', ''),
(31, 'The fundamental rights of citizens include rights to', 'life, speech and association', 'free education, employment and freedom of thought', 'life, liberty and property', 'association, property and social  security', 'a', '', 'Answer all Questions', '', '', '', ''),
(32, 'One argument against a multi-party system is the', 'banning of interest groups', 'encouragement of opposition and instability', 'high cost of conducting elections', 'inability to attract foreign assistance', 'b', '', 'Answer all Questions', '', '', '', ''),
(33, 'Public opinion is a view that is', 'held by the majority', 'widely publicized', 'no longer a secret', 'active in the public realm', 'b', '', 'Answer all Questions', '', '', '', ''),
(34, 'The political neutrality of civil servants implies that they', 'are not allowed to be involved in partisan politics', 'are not allowed to join any organization or group', 'have no dealings with politicians', 'are not allowed to vote', 'a', '', 'Answer all Questions', '', '', '', ''),
(35, 'When Nigeria achieved independence in 1960, the Head of State was the', 'President', 'Queen of England', 'Prime Minister', 'Governor-General', 'b', '', 'Answer all Questions', '', '', '', ''),
(36, 'Which of these constitutions recognized local government as a third tier of government in Nigeria?', '1979 Constitution', '1946 Constitution', '1960 Constitution', '1963 Constitution', 'a', '', 'Answer all Questions', '', '', '', ''),
(37, 'Before Nigeria became a Republic, the highest body charged with the administration of justice was the', 'Privy Council', 'High Court', 'Supreme Court', 'Court of Appeal', 'a', '', 'Answer all Questions', '', '', '', ''),
(38, 'The equivalent of a commissioner at the local government level is the', 'Councilor', 'Supervisory Councilor', 'Executive Chairman', 'Secretary', 'b', '', 'Answer all Questions', '', '', '', ''),
(39, 'The independent National Electoral Commission has the power to prepare and maintain the register of', 'political parties', 'constituencies', 'voters', 'electoral candidate', 'c', '', 'Answer all Questions', '', '', '', ''),
(40, 'During the Civil War, the major power that expressed moral support for Biafra\'s self determination was', 'France', 'China', 'the United States', 'Great Britain', 'a', '', 'Answer all Questions', '', '', '', ''),
(41, 'Nigeria\'s withdrawal from the Edinburgh Commonwealth Games in July 1986 was in protest against British', 'Support for UNITA rebels in Angola', 'supply of arms to Rhodesia', 'negative utterances on Nigeria', 'failure to impose sanction on South Africa', 'd', '', 'Answer all Questions', '', '', '', ''),
(42, 'The Economic Community of West African States has made impressive progress in the area of', 'free movement of persons and right of residence', 'increased trade among members', 'political integration of the region', 'providing financial aid to its members', 'a', '', 'Answer all Questions', '', '', '', ''),
(43, 'A major  way  of  maintaining  confidence \r\nin the  electoral  process is  by ensuring \r\nthat ', ' elections are conducted as and when \r\ndue', 'unlimited franchise is observed', ' electoral officers are regularly \r\ntrained ', 'elections are, conducted in a free \r\nand fair atmosphere ', 'd', '', 'Answer all Questions', '', '', '', ''),
(44, 'The final interpretation of the provision \r\nof a federal constitution is vested in the', 'highest legislative body', 'highest court of the land', 'head of state', 'Council of State \r\n', 'a', '', 'Answer all Questions', '', '', '', ''),
(45, 'The absence of the rule of law in \r\ngovernment will bring about ', 'corrupt practices ', ' political apathy', 'treasonable offences', 'human rights abuse', 'd', '', 'Answer all Questions', '', '', '', ''),
(46, 'One major factor that differentiates the \r\npresidential from the parliamentary system is', 'judicial independence', 'party system', 'separation of powers', 'passage of bills', 'c', '', 'Answer all Questions', '', '', '', ''),
(47, 'Capitalism is a system of economic organization based on', 'a mixed economy that takes all  interest into consideration', 'very fair distribution of the means of production', 'trading among people who own and control their items of trade', 'individual ownership of the means of production', 'd', '', 'Answer all Questions', '', '', '', ''),
(48, 'The Police Force belongs to which arm of Government?', 'Legislative', 'Judicial', 'Executive', 'Military', 'c', '', 'Answer all Questions', '', '', '', ''),
(49, 'Associations whose main interest is to influence public policies without having to capture power are', 'communal groups', 'trade unions', 'pressure groups', 'political parties', 'c', '', 'Answer all Questions', '', '', '', ''),
(50, 'Laws made by state governments are known as', 'edicts', 'bye-laws', 'decrees', 'acts', 'a', '', 'Answer all Questions', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `leader_led`
--

CREATE TABLE `leader_led` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leader_led`
--

INSERT INTO `leader_led` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The rhyming scheme of the above poem is', 'abab ', 'aabb ', 'abcc ', 'abcd', 'c', 'Questions Based on THE LEADER AND THE LED\r\n\r\nThe warthog is too ugly\r\nThe rhino too riotous\r\nAnd the pack thrashes around\r\nLike a snake without a head\r\n', '', '', '', '', ''),
(2, 'The first two lines of the above poem at good example of', 'hyperbole ', 'euphemism ', 'metonymy ', 'paradox', 'a', 'Questions Based on THE LEADER AND THE LED\r\n\r\nThe warthog is too ugly\r\nThe rhino too riotous\r\nAnd the pack thrashes around\r\nLike a snake without a head\r\n', '', '', '', '', ''),
(3, 'The last line of the above poem is good example of ', 'epigram ', 'synecdoche ', 'simile ', 'metaphor', 'c', 'Questions Based on THE LEADER AND THE LED\r\n\r\nThe warthog is too ugly\r\nThe rhino too riotous\r\nAnd the pack thrashes around\r\nLike a snake without a head\r\n', '', '', '', '', ''),
(4, 'The poet of the above poem is ', 'Dylon Thomas ', 'Kumar Farouk Sesay', 'Niyi Osundare', 'Agostinho Neto', 'c', 'Questions Based on THE LEADER AND THE LED\r\n\r\nThe warthog is too ugly\r\nThe rhino too riotous\r\nAnd the pack thrashes around\r\nLike a snake without a head\r\n', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `life_changer`
--

CREATE TABLE `life_changer` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `life_changer`
--

INSERT INTO `life_changer` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`) VALUES
(1, 'Who was behind the wheel as he changed to drive from kwangila to Ahmadu Bello University?\r\n', 'Habib', 'Labaran', 'Salihu  ', 'None of the above', 'b', 'Questions Based on LIFE CHANGER'),
(2, '____________and ____________ were Christians.\r\n', 'Salma and Ada', 'Salma and Tomiwa', 'Ada and Ngozi', 'None of the above', 'c', 'Questions Based on LIFE CHANGER'),
(3, 'Who was Omar’s immediate younger sister?\r\n', 'Bint  ', 'Teemah  ', 'Jamila ', 'None of the above', 'b', 'Questions Based on LIFE CHANGER'),
(4, '\"EMAL\" in the novel stands for\r\n', 'Electronic mailing', 'Exams malpractice', 'Exams practice', 'All of the above', 'b', 'Questions Based on LIFE CHANGER'),
(5, 'In the novel it was stated that ____________ is the second to English in the ranking of international languages\r\n', 'Mathematics ', 'French ', 'Social Studies', 'All of the above', 'b', 'Questions Based on LIFE CHANGER'),
(6, 'What earned Talle the tittle \'quiet one\'?\r\n', 'His troublesome character  ', 'His silent character ', 'His cheerful character', 'His playful character', 'b', 'Questions Based on LIFE CHANGER'),
(7, 'How many police vans came to stop outside the District head gate.\r\n', '3', '2', '4', '5', 'a', 'Questions Based on LIFE CHANGER'),
(8, 'Ummi’s matric number is\r\n', 'UP0001', 'UG0001', 'UG00001  ', 'UG0002', 'b', 'Questions Based on LIFE CHANGER'),
(9, 'Wow, that is some story, mum ____________ said\r\n', 'Bint  ', 'Teemah  ', 'Jamila ', 'Omar', 'd', 'Questions Based on LIFE CHANGER'),
(10, 'Ada is from ___________\r\n', 'Benue state', 'Imo state', 'Anambra  ', 'None of the above', 'a', 'Questions Based on LIFE CHANGER'),
(11, 'Who published the book “THE LIFE CHANGER” \r\n', 'Bolaji Abdullahi ', 'H Mohamed', 'Khadijat Abubakar Jalli ', 'Hammed Jalli', 'c', 'Questions Based on LIFE CHANGER'),
(12, '“And how do you say that’s very good in french, who asked this question.\r\n', 'The teacher', 'The French Mistress', 'Bint  ', 'None of the above', 'c', 'Questions Based on LIFE CHANGER'),
(13, 'What was the agreement between Ummi’s Father and Ummi before she graduated?\r\n', 'She should get married before she graduate', 'She should get married after her graduation', 'Marry before registration', 'None of the above', 'a', 'Questions Based on LIFE CHANGER'),
(14, 'Who was called the quiet one?\r\n', 'Talle ', 'Zaki  ', 'Hakimi Hakimi ', 'The Courtier', 'a', 'Questions Based on LIFE CHANGER'),
(15, 'How many times did Talle faint in the Hakimi residence?\r\n', 'Once  ', 'Twice ', 'Three times', 'He never fainted', 'b', 'Questions Based on LIFE CHANGER'),
(16, 'Who would never cook for just herself alone whether her roommates ate or not.\r\n', 'Ngozi ', 'Ada  ', 'Salma ', 'Tomiwa', 'a', 'Questions Based on LIFE CHANGER'),
(17, 'Omar scored ____________ credits including English and Mathematics at the very first attempt in his WAEC Examination\r\n', '8', '7', '5', '9', 'b', 'Questions Based on LIFE CHANGER'),
(18, 'Who was Bint telling the story of her classroom encounter with their meddlesome social studies teacher the previous week? \r\n', 'Ummi ', 'Omar ', 'Her two sisters', 'Her sister', 'c', 'Questions Based on LIFE CHANGER'),
(19, 'What is the name of Salma hostel?', 'Moremi hall', 'Queen Amina hall', 'Kofo hall', 'None of the above', 'b', 'Questions Based on LIFE CHANGER'),
(20, 'In Lafayette, the District head is known as ____________\r\n', 'Hakimi  ', 'Tomiwa  ', 'Sultan ', 'Johnson', 'a', 'Questions Based on LIFE CHANGER'),
(21, 'One there, the policemen followed Talle into the house and shortly the day after came out with a young boy of no more than ____________ years old\r\n', '12', '13', '11', '10', 'b', 'Questions Based on LIFE CHANGER'),
(22, 'How old was Omar when he gained admission into the university', '19', '18', '20', '21', 'b', 'Questions Based on LIFE CHANGER'),
(23, 'Who promised to upgrade Omar touch light phone to a smart android phone\r\n', 'Dad  ', 'Mum ', 'His sister’s', 'Mistress', 'a', 'Questions Based on LIFE CHANGER'),
(24, 'He was called Talle on account that shortly after his birth, his ____________ died\r\n', 'Stepmother  ', 'Father ', 'Grandfather  ', 'Mother', 'd', 'Questions Based on LIFE CHANGER'),
(25, 'In Lafayette, the tradition had since been established that no stranger was hosted or given accomodation without the knowledge and the approval of the ___________\r\n', 'District Leader', 'Community leader', 'Hakimi ', 'A and C', 'c', 'Questions Based on LIFE CHANGER'),
(26, 'Talle served as a ____________ at the local government office\r\n', 'Caterer  ', 'Barber ', 'Driver ', 'Carpenter', 'c', 'Questions Based on LIFE CHANGER'),
(27, 'Why did Omar have to wait two days before checking his admission status\r\n', 'He was afriad to check', 'He had a bad dream', 'He did not have a smart phone', 'All of the above', 'c', 'Questions Based on LIFE CHANGER'),
(28, 'Omar was dressed in ____________ jean and ____________ shirts when he went to greet his mom in the morning\r\n', 'White and blue', 'Blue and white', 'White and black', 'Blue and black', 'b', 'Questions Based on LIFE CHANGER'),
(29, 'Who did Salma became close to in the room all because she was in the know of the latest and craziest fashion outfits.\r\n', 'Ada  ', 'Ngozi  ', 'Tomiwa ', 'None', 'c', 'Questions Based on LIFE CHANGER'),
(30, 'Who assisted Ummi’s husband with Ummi admission?\r\n', 'Dr. Samuel Johnson', 'Tomiwa', 'Samuel Johnson', 'Johnson', 'a', 'Questions Based on LIFE CHANGER');

-- --------------------------------------------------------

--
-- Table structure for table `lion_jewel`
--

CREATE TABLE `lion_jewel` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lion_jewel`
--

INSERT INTO `lion_jewel` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The dramatist of the play is --------', 'Buchi Emecheta', 'Ola Rotimi', 'Wale Soyinka', 'John Smith', 'c', 'Questions Based on THE LION AND THE JEWEL ', '', '', '', '', ''),
(2, 'The protagonist of the play is --------', 'Sidi ', 'Sadiku ', 'Baroka ', 'Esther', 'a', 'Questions Based on THE LION AND THE JEWEL ', '', '', '', '', ''),
(3, 'The lion of Ilujinle village is ------- ', 'Lakunle ', 'Baroka ', 'Okiki ', 'Sidi', 'b', 'Questions Based on THE LION AND THE JEWEL ', '', '', '', '', ''),
(4, 'Sidi honored Baroka\'s visit to ------- him', 'marry ', 'know ', 'mock ', 'play with', 'c', 'Questions Based on THE LION AND THE JEWEL ', '', '', '', '', ''),
(5, '\"Paying the bride price of a woman is a savage custom\". This was said by-------', 'The whiteman', 'Lakunle ', 'Baroka ', 'Geography teacher', 'b', 'Questions Based on THE LION AND THE JEWEL ', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `literature`
--

CREATE TABLE `literature` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `instruction` longtext NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `literature`
--

INSERT INTO `literature` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `qimage`, `instruction`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'A piece of writing or speech at the beginning of a work of art is the', 'prologue', 'dialogue', 'monologue', 'introduction', 'a', '', 'Answer All Questions', '', '', '', ''),
(2, 'The main objective of drama is to ____', 'educate us', 'entertain us', 'educate and\r\nentertain us', 'strengthen and beautify us', 'c', '', 'Answer All Questions', '', '', '', ''),
(3, 'In literature, another name for denouement is _____', 'resolution', 'reference', 'inference', 'accusation', 'a', '', 'Answer All Questions', '', '', '', ''),
(4, 'A common attribute of a play is its\r\npossession of a(n) _______', 'conflict', 'epilogue ', 'sarcasm ', 'prologue ', 'a', '', 'Answer All Questions', '', '', '', ''),
(5, 'If the sound of a word suggests its probable meaning, we have a case of______________', 'euphemism', 'onomatopoeia ', 'criticism', 'litotes', 'b', '', 'Answer All Questions', '', '', '', ''),
(6, '_____ applies to both tragedy and comic\r\nplays. ', 'plot', 'horrifying ending', 'happy ending', 'bomb blast', 'a', '', 'Answer All Questions', '', '', '', ''),
(7, 'Which of the following options is the stronghold of poetry?', 'emotion only', 'ideas only', 'beauty only', 'all of the above', 'a', '', 'Answer All Questions', '', '', '', ''),
(8, 'A narration is said to be an epistolary work if it is largely conceived in ______', 'essays ', 'episodes ', 'arguments ', 'letters', 'd', '', 'Answer All Questions', '', '', '', ''),
(9, 'In the poetic line, \"I am the enemy you killed, my friend,\" the literary device most noticeable there is a/an ___', 'hyperbole', 'oxymoron', 'onomatopoeia', 'synaesthesia', 'b', '', 'Answer All Questions', '', '', '', ''),
(10, '\"What is our life?\r\nA play of passion?\"\r\n\r\nWhat is the pronounced device deployed in that single poetic line? A/An_____ ', 'simile', 'rhetorical question', 'allusive phraseology', 'metaphor', 'b', '', 'Answer All Questions', '', '', '', ''),
(11, '____ is a central organising element linking figure(s), action, style and language in a piece of fiction.', 'setting', 'plot', 'characterisation', 'theme', 'd', '', 'Answer All Questions', '', '', '', ''),
(12, 'The outline of a story in a logical order is\r\nreferred to as ______', 'plot', 'outline', 'storyline', 'flashback', 'a', '', 'Answer All Questions', '', '', '', ''),
(13, 'A narrative poem ____', 'preaches a sermon', 'propounds a philosophy', 'tells a tale or story', 'argues in a narrative manner', 'c', '', 'Answer All Questions', '', '', '', ''),
(14, 'One of the following makes use of gesture\r\nonly___________', 'Comedy', 'Lampoon', 'Mime', 'Satire', 'c', '', 'Answer All Questions', '', '', '', ''),
(15, 'An epilogue ________', 'introduces a play', 'develops characters', 'sums up a play', 'introduces characters', 'c', '', 'Answer All Questions', '', '', '', ''),
(16, 'Like the dew on the thorn\r\nLike the foam below a valley\r\nLike the bubble on a sweet babe born\r\nThou art gone, for ever rarely\r\nThe rhyme scheme of the above extract is ______\r\n', 'anxiety', 'sorrow', 'joy', 'excitement', 'b', '', 'Answer All Questions', '', '', '', ''),
(17, 'Like the dew on the thorn\r\nLike the foam below a valley\r\nLike the bubble on a sweet babe born\r\nThou art gone, for ever rarely\r\nThe rhyme scheme of the above extract is ______\r\n', 'personification', 'repetition', 'hyperbole', 'paradox ', 'b', '', 'Answer All Questions', '', '', '', ''),
(18, 'Like the dew on the thorn\r\nLike the foam below a valley\r\nLike the bubble on a sweet babe born\r\nThou art gone, for ever rarely\r\nThe rhyme scheme of the above extract is ______\r\n', 'abba', 'abab', 'aabb', 'abcd', 'b', '', 'Answer All Questions', '', '', '', ''),
(19, '\'A joyful tear\' is an example of which\r\nfigure of speech?', 'simile', 'metaphor', 'hyperbole', 'oxymoron', 'd', '', 'Answer All Questions', '', '', '', ''),
(20, 'The principal female character in a novel\r\nis called _______', 'hero', 'villain', 'heroine', 'clown', 'c', '', 'Answer All Questions', '', '', '', ''),
(21, 'The last part of a literary work is known\r\nas__', 'acknowledgement', 'epilogue', 'climax', 'ending', 'b', '', 'Answer All Questions', '', '', '', ''),
(22, 'The identical sound at the end of a poem\r\nis known as', 'metre', 'rhythm', 'rhyme', 'verse ', 'c', '', 'Answer All Questions', '', '', '', ''),
(23, 'A protagonist who has a disastrous end is a _____', 'comic character', 'flat character', 'round cast', 'tragic hero', 'd', '', 'Answer All Questions', '', '', '', ''),
(30, 'Which of the following does not define a\r\ncharacter? ', 'What the character does', 'what others say\r\nabout the character', 'the way the character\r\nappears', 'the character\'s mannerism.', 'b', '', 'Answer All Questions', '', '', '', ''),
(31, 'Which of the following is not a type of\r\nplay?', 'Tragedy', 'Tragic flaw', 'Comedy', 'farce', 'b', '', 'Answer All Questions', '', '', '', ''),
(32, 'A short introductory speech delivered as a part of a play is called', 'a preamble', 'a\r\nprologue', 'an introduction', 'an epilogue', 'b', '', 'Answer All Questions', '', '', '', ''),
(33, 'Pick the odd one of the option listed.', 'euphemism', 'oxymoron', 'hyperbole', 'rhythm', 'd', '', 'Answer All Questions', '', '', '', ''),
(34, 'The major distinctive feature of drama is', 'dialogue', 'setting', 'epilogue', 'plot', 'a', '', 'Answer All Questions', '', '', '', ''),
(35, 'A poem written in praise of someone or\r\nsomething is', 'a ballad', 'an epic', 'a\r\nsonnet', 'lullaby', 'b', '', 'Answer All Questions', '', '', '', ''),
(36, 'The central idea of a story or poem is the', 'title', 'climax', 'theme', 'conflict', 'c', '', 'Answer All Questions', '', '', '', ''),
(37, 'The timing and location of literary work is ______ ', 'theme', 'plot', 'setting', 'atmosphere', 'c', '', 'Answer All Questions', '', '', '', ''),
(38, 'The elegy ____', 'conforms to a fixed\r\npattern of lines', 'is set in the countryside', 'has a mournful tone', 'celebrates heroic deeds', 'c', '', 'Answer All Questions', '', '', '', ''),
(39, 'The major genre of literature are ______', 'fiction, non-fiction, drama', 'prose, farce,\r\ncomedy', 'prose, drama, poetry', 'poetry,\r\nprose, fiction', 'c', '', 'Answer All Questions', '', '', '', ''),
(40, 'A literary work in which the characters and events are used as symbols is known as', 'characterization', 'allegory', 'metaphor', 'parallelism', 'b', '', 'Answer All Questions', '', '', '', ''),
(41, 'Characterization in a novel refers to the', 'writer\'s opinion of the characters', 'way the characters are revealed to the reader', 'characters and the way they behave', 'reader\'s opinion of the characters', 'b', '', 'Answer All Questions', '', '', '', ''),
(42, 'In literary work, verbal irony refers to a', 'device in which the speaker means the opposite of what he says', 'situation in which a character speaks or acts against the trend of events', 'difficult situation which defies a logical or rational resolution', 'device in which the actor on stage means exactly what he says', 'a', '', 'Answer All Questions', '', '', '', ''),
(43, 'In the theatre, words spoken by a character that are meant to be heard by the audience but not by other characters on stage is called', 'aside', 'soliloquy', 'acoustic', 'tone', 'a', '', 'Answer All Questions', '', '', '', ''),
(44, 'Drama is the representation of a complete series of actions by means of', 'movement and gesture for the screen and audience', 'speech, movement and gesture for the stage only', 'speech, movement and gesture for the stage, screen and radio', 'speech, gesture and movement for the screen and radio', 'c', '', 'Answer All Questions', '', '', '', ''),
(45, 'A poet\'s use of regular rhythm is known as', 'allegory', 'assonance', 'metre', 'onomatopoenia', 'c', '', 'Answer All Questions', '', '', '', ''),
(46, 'A literary genre which directly imitates human action is', 'drama', 'comedy', 'prose', 'poetry', 'a', '', 'Answer All Questions', '', '', '', ''),
(47, 'A fable is a story in which', 'allegations are made about a character', 'animals or things are used as characters', 'there is an important setting', 'the story is told in poetic form', 'b', '', 'Answer All Questions', '', '', '', ''),
(48, 'The juxtaposition of two contrasting ideas in a line of poetry is', 'euphemism', 'synecdoche', 'catharsis', 'oxymoron', 'd', '', 'Answer All Questions', '', '', '', ''),
(49, 'The main aim of caricature is to', 'describe', 'expose', 'emphasize', 'ridicule', 'd', '', 'Answer All Questions', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `sn` int(2) NOT NULL,
  `name` varchar(100) NOT NULL,
  `un` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `pp` varchar(100) NOT NULL,
  `timermin` int(100) NOT NULL,
  `submitstatus` int(10) NOT NULL,
  `backup` text NOT NULL,
  `psgid` varchar(5) NOT NULL,
  `sub2` varchar(30) NOT NULL,
  `sub3` varchar(30) NOT NULL,
  `sub4` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mathematics`
--

CREATE TABLE `mathematics` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mathematics`
--

INSERT INTO `mathematics` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'Evaluate 21.05347 - 1.6324 x 0.43, to 3 decimal places.', '20.980', '20.351', '20.981', '20.352', 'c', 'Answer All Questions', '', '', '', '', ''),
(2, 'What is the slope of the line containing the points (-9,2) and (3,14)?', '1', '-1', '-3/8', '-2', 'a', 'Answer All Questions', '', '', '', '', ''),
(3, 'Evaluate 3(x + 2) > 6(x + 3)', 'x > - 4', 'x < - 4', 'x > 4', 'x < 4', 'b', 'Answer All Questions', '', '', '', '', ''),
(5, 'At Bison High School, there are 16 students in English Club, 16 students in Science Club and 20 students in Math Club.  Of these students, there are 5 students in both the English and Science Clubs; 6 students in both the Science and Math Clubs; and 8 in both the English and Math Clubs.  If only 2 students are in all three clubs, how many students are in at least one of the clubs?', '52', '35', '30', '20', 'b', 'Answer All Questions', '', '', '', '', ''),
(6, 'Trina has a college fund started with a deposit of  N10,000 which earns 5% annually.  If no other monies are deposited, how much money will Trina have in her fund at the end of three years?', 'N11,500', 'N11,576.25', 'N15,000', 'N25,000', 'b', 'Answer All Questions', '', '', '', '', ''),
(7, '', '1', '-1', '3/2', '-3/2', 'b', 'Answer All Questions', 'mth1.JPG', '', '', '', ''),
(8, 'The mean of 7 numbers is 10. When another number is added the mean is reduced to 9.5; the new number is', '10', '9.5', '6', '7/2', 'c', 'Answer All Questions', '', '', '', '', ''),
(9, 'If r and s are roots that satisfy the above equation, then (r + s)=', '2/3', '-1/6', '1/3', '-1/3', 'd', 'Answer All Questions', 'mth2.JPG', '', '', '', ''),
(10, 'The gradient of the equation of a curve stated above at the point P is 4. The coordinates of P are', '(3,6)', '3,-6)', '(4,0)', '(-1,10)', 'b', 'Answer All Questions', 'mth3.JPG', '', '', '', ''),
(11, '', '20pi', '32pi', '24pi', '8pi', 'a', 'Answer All Questions', 'mth4.JPG', '', '', '', ''),
(12, 'The common ratio of a geometrical progression is 2. If the 5th term is greater than the first term by 45, what is the first term?', '4', '5', '6', '3', 'd', 'Answer All Questions', '', '', '', '', ''),
(13, '', '1,2,-3', '-1,2,3', '-1,2,-3', '1,-2,3', 'd', 'Answer All Questions', 'mth5.JPG', '', '', '', ''),
(14, 'The sum of infinite series 1, 1/2, 1/4,  1/8 _______ is', '1', '3', '2', '1/2', 'c', 'Answer All Questions', '', '', '', '', ''),
(15, '', 'distinct roots', 'equal roots', 'complex root', 'none of the above', 'b', 'Answer All Questions', 'mth6.JPG', '', '', '', ''),
(16, 'A bag contains 16 black, 14 white and x red marbles. If the probability of picking a red marble is   2/5, find the value of x.', '10', '21', '20', 'None of the above', 'c', 'Answer All Questions', '', '', '', '', ''),
(17, 'If  39th term of an A.P is 141, what is the first term if the common difference is 2?', '141', '65', '39', 'none of the above', 'b', 'Answer All Questions', '', '', '', '', ''),
(18, '', '2t/3', '3t/2', 't + 1/t', 'y/x', 'b', 'Answer All Questions', 'mth7.JPG', '', '', '', ''),
(19, 'Find the value of sin 210 degrees', '', '', '-1/2', '1/2', 'c', 'Answer All Questions', '', 'mth8a.png', 'mth8b.png', '', ''),
(20, 'A shop sells bananas at 6 for N100. A trader sells the same kind of bananas at 8 for  N120. Which price is cheaper, and by how much per banana?', '8 for  N120;  N1.67', '8 for N120; N15', '8 for N120; N16.67', '6 for 100; N6', 'a', 'Answer All Questions', '', '', '', '', ''),
(21, 'A student spent 1/5 of his allowances on books, 1/3 of the remainder on food and kept the rest on contingencies. What fraction was kept?', '7/15', '8/15', '2/3', '4/5', 'b', 'Answer All Questions', '', '', '', '', ''),
(22, 'In a school inter-house sport competition, 80% of the students turned up at the athletic event and 60% attended the football match. What percentage of the students attended both events?', '50%', '70%', '40%', 'none of the above', 'c', 'Answer All Questions', '', '', '', '', ''),
(23, 'A box contains two red balls and four blue balls. A ball is picked at random from the box and then replaced before a second ball is drawn. Find the probability of drawing two red balls', '4/16', '1/4', '2/5', 'none of the above', 'd', 'Answer All Questions', '', '', '', '', ''),
(24, 'What value of x makes the function x(4-x) maximum?', '4', '3', '2', '1', 'c', 'Answer All Questions', '', '', '', '', ''),
(25, 'If the 7th term of an A.P is twice the third term and sum of the first four terms is 42. Find the common difference', '6', '3', '2', '1', 'b', 'Answer All Questions', '', '', '', '', ''),
(26, 'Express 495 g as a percentage of 16.5 kg', '33%', '3%', '30%', '33.3%', 'b', 'Answer All Questions', '', '', '', '', ''),
(27, '', '3.4471', '2.4471', '1.4471', '1.4071', 'b', 'Answer All Questions', 'mth9.JPG', '', '', '', ''),
(28, '', '', '', '', '', 'c', 'Answer All Questions', 'mth10.JPG', 'mth10a.png', 'mth10b.png', 'mth10c.png', 'mth10d.png'),
(29, 'Evaluate the determinant above', '-12', '-4', '4', '-2', 'c', 'Answer All Questions', 'mth11.png', '', '', '', ''),
(30, '', '(2, 3) and (3, 5)', '(2, 5) and (5, 2)', '(5, 2) and (5, 3)', '(5, 3) and (3, 5)', 'b', 'Answer All Questions', 'mth12.JPG', '', '', '', ''),
(31, 'Find  the  number  of  sides  of  a  regular polygon  whose  exterior  angle  is  twice  the interior angle.', '6', '2', '3', '8', 'a', 'Answer All Questions', '', '', '', '', ''),
(32, '', '4', '3', '2', '1', 'c', 'Answer All Questions', 'mth13.JPG', '', '', '', ''),
(33, '', 'a^x - 2', 'a^x + 2', 'a^x - 18', 'a^x - 6', 'a', 'Answer All Questions', 'mth14.JPG', '', '', '', ''),
(35, 'Convert 27(base 10) to another number in base three.', '1010(base 3)', '1100(base 3)', '1000(base 3)', '1001(base 3)', 'b', 'Answer All Questions', '', '', '', '', ''),
(36, 'Find the value of the angle indicated', '120(degrees)', '100(degrees)', '30(degrees)', '60(degrees)', 'a', 'Answer All Questions', 'mth15.png', '', '', '', ''),
(37, 'In  the  figure  above,  PQR  is  a  straight  line segment,  /PQ/ =  /QT/.   Triangle  PQT is an isosceles  triangle,  angle SRQ  is  75(degrees)  and  angle QPT  is 25(degrees). Calculate the value of angle RST.', '45(degrees)', '55(degrees)', '25(degrees)', '50(degrees)', 'b', 'Answer All Questions', 'mth16.png', '', '', '', ''),
(38, 'The  bearings  of  P  and  Q  from  a  common point N are 020(degrees) and 300(degrees) respectively. If P and Q are also equidistant from N, find the bearing of P from Q.', '040(degrees)', '070(degrees)', '280(degrees)', '320(degrees)', 'b', 'Answer All Questions', '', '', '', '', ''),
(39, 'P(-6, 1) and Q(6, 6) are the two ends of the diameter  of  a  given  circle. Calculate  the radius.', '6.5 units', '13.0 units', '3.5 units', '7.0 units', 'a', 'Answer All Questions', '', '', '', '', ''),
(40, 'The  identity  element  with  respect  to  the multiplication shown in the table above is ', '0', 'm', 'l', 'k', 'b', 'Answer All Questions', 'mth17.png', '', '', '', ''),
(41, 'The mean score is', '7.0', '8.7', '9.5', '11.0', 'b', 'Answer All Questions', 'mth18.png', '', '', '', ''),
(42, 'Find the square of the mode.', '49', '121', '25', '64', 'b', 'Answer All Questions', 'mth18.png', '', '', '', ''),
(43, '', '300', '720', '512', '10!', 'b', 'Answer All Questions', 'mth19.JPG', '', '', '', ''),
(44, 'Teams A and B are involved in a game of football. What is the probability that the game ends in a draw?', '3/2', '2/2', '100', '1/2', 'd', 'Answer All Questions', '', '', '', '', ''),
(45, 'The histogram above shows the distribution of passengers in taxis of a certain motor pack. How many taxis have more than 4 passengers?', '16', '17', '14', '15', 'b', 'Answer All Questions', 'mth20.png', '', '', '', ''),
(46, 'Find the variance of 2, 6, 8, 6, 2 and 6.', '5', '6', '(root)6', '(root)5', 'a', 'Answer All Questions', '', '', '', '', ''),
(47, 'The bar chart above shows different colours of cars passing a particular point of a certain street in two minutes. What fraction of the total number of cars is yellow?', '3/25', '2/25', '1/5', '4/15', 'a', 'Answer All Questions', 'mth21.png', '', '', '', ''),
(48, 'Find the range of 1/6, 1/3, 3/2, 3/2, 8/9 and 4/3', '3/4', '5/6', '7/6', '4/3', 'd', 'Answer All Questions', '', '', '', '', ''),
(49, 'A car dealer bought a second-hand car for N250,000.00  and  spent  N70,000.00 refurbishing  it.  He  then  sold  the  car  for N400,000.00. What is the percentage gain?', '60%', '32%', '25%', '20%', 'c', 'Answer All Questions', '', '', '', '', ''),
(50, 'Find the number of ways of selecting 7 subjects from 11 subjects for an examination.', '330', '1663200', '300', '1663300', 'a', 'Answer All Questions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `midsummer`
--

CREATE TABLE `midsummer` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `midsummer`
--

INSERT INTO `midsummer` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'Who is the speaker?', 'Puck ', 'Demetrius ', 'Lysander ', 'Theseus', 'b', 'Questions Based on MID SUMMER\'S NIGHT\'S DREAM\r\n\r\nMy Lord fair Helena told me of their stealth,\r\nOf this their purpose hither in the wood,\r\nAnd I in fairy hither followed them,\r\nFair Helena in fancy following me.\r\nBut my good lord,I wot not by what power-\r\nBut by some power it is-my love to Hermia.\r\n', '', '', '', '', ''),
(2, 'Who was this said to? ', 'Theseus ', 'Lysander ', 'Queen ', 'Egeus', 'd', 'Questions Based on MID SUMMER\'S NIGHT\'S DREAM\r\n\r\nMy Lord fair Helena told me of their stealth,\r\nOf this their purpose hither in the wood,\r\nAnd I in fairy hither followed them,\r\nFair Helena in fancy following me.\r\nBut my good lord,I wot not by what power-\r\nBut by some power it is-my love to Hermia.\r\n', '', '', '', '', ''),
(3, 'Who was being talked about here?', 'Helena ', 'Hermia ', 'Lysander ', 'Egeus', 'b', 'Questions Based on MID SUMMER\'S NIGHT\'S DREAM\r\n\r\nMy Lord fair Helena told me of their stealth,\r\nOf this their purpose hither in the wood,\r\nAnd I in fairy hither followed them,\r\nFair Helena in fancy following me.\r\nBut my good lord,I wot not by what power-\r\nBut by some power it is-my love to Hermia.\r\n', '', '', '', '', ''),
(4, 'Whose \"stealth\"?', 'Bottom-Titania', 'Oberon - Titania ', 'Demetrius - Helena', 'Lysander - Hermia', 'd', 'Questions Based on MID SUMMER\'S NIGHT\'S DREAM\r\n\r\nMy Lord fair Helena told me of their stealth,\r\nOf this their purpose hither in the wood,\r\nAnd I in fairy hither followed them,\r\nFair Helena in fancy following me.\r\nBut my good lord,I wot not by what power-\r\nBut by some power it is-my love to Hermia.\r\n', '', '', '', '', ''),
(5, 'I wot not...\".(line5) means ', 'I work not ', 'I\'m worth not', 'I know not', 'I care not', 'c', 'Questions Based on MID SUMMER\'S NIGHT\'S DREAM\r\n\r\nMy Lord fair Helena told me of their stealth,\r\nOf this their purpose hither in the wood,\r\nAnd I in fairy hither followed them,\r\nFair Helena in fancy following me.\r\nBut my good lord,I wot not by what power-\r\nBut by some power it is-my love to Hermia.\r\n', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `physics`
--

CREATE TABLE `physics` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `physics`
--

INSERT INTO `physics` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'If the distance between two suspended masses 10kg each is tripled, the gravitational force of attraction between them is reduced by', 'a ninth', 'a half', 'a third', 'a quarter', 'a', 'Answer All Questions', '', '', '', '', ''),
(2, '', '200pi hertz', '200 hertz', '100 hertz', '20 hertz', 'c', 'Answer All Questions', 'phy1.JPG', '', '', '', ''),
(3, 'A body which weighs 50N in air displaces 3.7kg of water when partially immersed in water. Calculate the up-thrust on the body.', '8.7N', '13.0N', '87.0N', '37.0N', 'd', 'Answer All Questions', '', '', '', '', ''),
(4, 'An object is positioned between two plane mirrors inclined at angle 120(degrees) to each other.\r\nThe object is 1 unit distant from each mirror. The number of images formed is', '2', '3', '4', '5', 'a', 'Answer All Questions', '', '', '', '', ''),
(5, 'The property that is propagated in a traveling wave is', 'frequency', 'amplitude', 'energy', 'wavelength', 'c', 'Answer All Questions', '', '', '', '', ''),
(6, 'A conductor of length 2m carries a current of 0.8A while kept in a magnetic field of magnetic flux density 0.5T. The maximum force acting on it is ', '16.2N ', '8.0N ', '3.2N ', '0.8N', 'd', 'Answer All Questions', '', '', '', '', ''),
(7, 'To keep a vehicle moving at a constant speed v, requires power P. from the engine. The force provided by the engine is', 'p/v', 'v/2', 'pv   ', 'p/2v', 'a', 'Answer All Questions', '', '', '', '', ''),
(8, 'Which of the following sources of energy is non-renewable?', 'biomass  ', 'solar  ', 'wind  ', 'tides ', 'a', 'Answer All Questions', '', '', '', '', ''),
(9, 'Which one of the following colour is most likely to produce a photo-electron with the highest kinetic energy.', 'Red ', 'Yellow ', 'Blue  ', 'Green', 'a', 'Answer All Questions', '', '', '', '', ''),
(10, 'I. Mass II. Density III. Temperature IV. Nature of substance.\r\nWhich of the above affect diffusion?', ' I, II and IV only', 'II, III and IV only', 'I, II, III and IV', 'I and II only', 'c', 'Answer All Questions', '', '', '', '', ''),
(11, 'When left in a freezer, a bottle full of water cracks on freezing into ice because of the', 'decrease in the volume of water', 'contraction in the volume', 'expansion of the bottle', 'increase in the volume of water', 'd', 'Answer All Questions', '', '', '', '', ''),
(12, '', '1.5 %', '1.1 %', '0.4%', '0.1%', 'b', 'Answer All Questions', 'phy2.JPG', '', '', '', ''),
(13, 'An athlete can take a longer jump if he comes running from a distance as compared to that when he jumps suddenly. Identify the type of inertia.', 'inertia of rest', 'inertia of motion', 'inertia of direction', 'inertia of position', 'b', 'Answer All Questions', '', '', '', '', ''),
(14, 'A ball takes t second to fall from a height h1 and 2t seconds to fall from a height h2. Then h2/h1 is: ', ' 0.5', '0.25   ', '2', '4', 'd', 'Answer All Questions', '', '', '', '', ''),
(15, 'The acceleration in a body is due to', 'balanced force', 'unbalanced force', 'mass defect', 'electrostatic force', 'b', 'Answer All Questions', '', '', '', '', ''),
(16, 'A force of 20 N stretches a spring to a total length of 30 cm. An additional force of 10 N stretches the spring 5 cm further. Find the natural length of the spring', '25.0 cm', '22.5 cm', '20.0 cm', '15.0 cm', 'c', 'Answer All Questions', '', '', '', '', ''),
(17, 'A car moving with a speed of 90kmh-1 was brought uniformly to rest by the application of the brakes in 10s. How far did the car travel after the brakes were applied?', '125m        ', '150m          ', '250m    ', '15km', 'a', 'Answer All Questions', '', '', '', '', ''),
(18, 'A stone of mass mkg is held h meters above the flour for 50s. The work done in Joules over this period is ', 'mh', 'mgh  ', '0', 'mgh/50', 'c', 'Answer All Questions', '', '', '', '', ''),
(19, 'Four co-planar forces of magnitude 10N, 17N, 6N and 20N act at a point O as shown in the diagram above. Determine the magnitude of the resultant force', '53.0N ', '21.0N ', '7.0N ', '5.0N', 'd', 'Answer All Questions', 'phy3.png', '', '', '', ''),
(20, 'A ray of light strikes a plane mirror at a glancing angle of 50(degrees). Calculate the angle between the incident and reflected rays. ', '100(degrees)', '40(degrees)', '50(degrees)', '80(degrees)', 'd', 'Answer All Questions', '', '', '', '', ''),
(21, 'Which of the following is true of light and sound waves?', 'they both transmit energy', 'they both need a material medium for propagation', 'they are both transverse waves', 'their velocities in air are equal.', 'a', 'Answer All Questions', '', '', '', '', ''),
(22, 'Which of the following waves is both mechanical and transverse? ', ' X-ray', 'Sound wave', 'Water-wave ', 'Radio wave', 'c', 'Answer All Questions', '', '', '', '', ''),
(23, 'PQ is a uniform metre rule pivoted at 35.0cm mark.  A mass of 50g is then hung at the 15.0cm mark such that the rule balances horizontally, calculate the mass of the metre rule.', '55.0g', '66.7g', '75.0g', '77.7g', 'b', 'Answer All Questions', '', '', '', '', ''),
(24, 'Two balls are dropped from same height at 1 second interval of time. The separation between the two balls after 3 seconds of the drop of first ball is:', '50m ', '40m', '35m', '25m', 'c', 'Answer All Questions', '', '', '', '', ''),
(25, 'I.  Moon  II. Sun	  III.  Street light  IV Stars. \r\nWhich of the following is natural source of light?\r\n', 'II, III and IV only', 'I, II and III only', 'III and IV only', 'II and IV only', 'd', 'Answer All Questions', '', '', '', '', ''),
(26, 'A transistor is used in the amplification of signals because it', 'controls the flow of current', 'consumes a lot of power', 'allows doping', 'contains electron and hole carriers', 'a', 'Answer All Questions', '', '', '', '', ''),
(27, 'The unit of thermal conductivity is', 'J/s', 'W/mK', 'Wm/K', 'Kelvin', 'b', 'Answer All Questions', '', '', '', '', ''),
(28, 'The temperature gradient across a copper rod of thickness 0.02m, maintained at two temperature junctions\r\n of 20 (degree Celsius) and 80(degree Celsius) is', '3 e2 Kelvin per Metre', '3 e3 Kelvin per Metre', '5 e3 Kelvin per Metre', '3 e4 Kelvin per Metre', 'b', 'Answer All Questions', '', '', '', '', ''),
(29, 'Highly polished silvery surfaces are', 'poor absorbers and poor emitters of radiation', 'good absorbers and good emitters of radiation', 'good absorbers but poor emitters of radiation', 'poor absorbers but good emitters of radiation', 'a', 'Answer All Questions', '', '', '', '', ''),
(30, 'The maximum density of water is at', '- 4 (degree  Celsius)', '0(degree  Celsius)', '100(degree  Celsius)', '4(degree  Celsius)', 'd', 'Answer All Questions', '', '', '', '', ''),
(31, 'Calculate the temperature change when 500J of heat is supplied to 100g of water.(specific heat capacity of water = 4200J/kgk)', '12.1 (degree  Celsius)', '2.1(degree  Celsius)', '1.2(degree  Celsius)', '0.1(degree  Celsius)', 'c', 'Answer All Questions', '', '', '', '', ''),
(32, 'The melting point of a certain solid is measured to be 70(degree  Celsius). What is this temperature in Kelvin and degrees Fahrenheit respectively?', '158K and 158(degree  Fahrenheit )', '343K and 158(degree  Fahrenheit )', '334K and 158(degree  Fahrenheit )', '343K and 212(degree  Fahrenheit )', 'b', 'Answer All Questions', '', '', '', '', ''),
(33, 'At resonance, the phase angle in an a.c. circuit is', '0(degree)', '60(degrees)', '90(degrees)', '180(degrees)', 'a', 'Answer All Questions', '', '', '', '', ''),
(34, 'When a ball rolls on a smooth level ground, the motion of its centre is', 'translational', 'oscillatory', 'random', 'rotational', 'a', 'Answer All Questions', '', '', '', '', ''),
(35, 'Thunder is usually heard some seconds after lighting is seen because', 'sound and light travel in different media', 'thunder occurs after lighting', 'sound travels in the form of waves but light does not', 'sound travel more slowly than light', 'd', 'Answer All Questions', '', '', '', '', ''),
(36, 'How long will it take to heat 3kg of water from 28(degree Celsius) to 88(degree Celsius) using an electric kettle, which taps 6A from a 210V supply?', '5.6 minutes', '9.6 minutes', '10.0 minutes', '600 minutes', 'c', 'Answer All Questions', '', '', '', '', ''),
(37, 'The quality (timber) of sound depends', 'wavelength', 'frequency', 'amplitude', 'harmonics', 'd', 'Answer All Questions', '', '', '', '', ''),
(38, 'An arrow of mass 0.1kg moving with a horizontal velocity of 15 m/s is shot into a wooden block of mass 0.4kg lying at rest on a smooth horizontal surface. Their common velocity after impact is', '15.0 m/s', '7.5 m/s', '3.8 m/s', '3.0 m/s', 'd', 'Answer All Questions', '', '', '', '', ''),
(39, '', '33(degree Celsius)', '60(degree Celsius)', '87(degree Celsius)', '114(degree Celsius)', 'a', 'Answer All Questions', 'phy4.JPG', '', '', '', ''),
(40, 'When a ship sails from salt water into fresh water, the fraction of its volume above the water surface will', 'remain the same', 'increase', 'decrease', 'increase then decrease', 'c', 'Answer All Questions', '', '', '', '', ''),
(41, 'The period of vibration of a wave of wavelength 30m moving at a speed of 300m/s', '10s', '270s', '0.1s', '900s', 'c', 'Answer All Questions', '', '', '', '', ''),
(42, 'Which of the following does not use magnetic effect of current to function?', 'A telephone receiver', 'Lead acid accumulator', 'A moving coil galvanometer', 'An electric bell', 'b', 'Answer All Questions', '', '', '', '', ''),
(44, 'A concave mirror of radius of curvature 40cm forms a real image twice as large as the object. The object distance is', '30cm', '10cm', '40cm', '60cm', 'a', 'Answer All Questions', '', '', '', '', ''),
(45, 'The phenomenon that makes sound persist when its source has been removed is known as', 'acoustic vibration', 'rarefaction', 'echo', 'reverberation', 'd', 'Answer All Questions', '', '', '', '', ''),
(46, 'The eye controls the amount of light reaching the retina by adjusting the', 'cornea', 'iris', 'retina', 'optic nerve', 'b', 'Answer All Questions', '', '', '', '', ''),
(47, 'A car of mass 100kg moves at a constant speed of 20m/s along a horizontal road where the friction force is 200N. Calculate the power developed by the engine.', '2000 watt', '3000 watt', '4000 watt', '5000 watt', 'c', 'Answer All Questions', '', '', '', '', ''),
(48, 'What particle is X in the reaction above?', 'Alpha', 'Beta', 'Neutron', 'Gamma', 'c', 'Answer All Questions', 'phy5.png', '', '', '', ''),
(49, 'The energy associated with the photon of a radio transmission at 3 e 5 Hz is\r\n[h = 6.63 e -34 Js]', '2.00 x 10^-28 J', '1.30 x 10^-28 J', '2.00 x 10^-29 J', '1.30 x 10^-29 J', 'a', 'Answer All Questions', '', '', '', '', ''),
(50, 'The electromagnetic wave that can produce a heating effect on the environment is', 'X-rays', 'ultraviolet rays', 'infra-red rays', 'gamma rays', 'c', 'Answer All Questions', '', '', '', '', ''),
(51, 'A current of 0.5A flowing for 3 hours deposits 10g of a metal during electrolysis. The quantity of the same metal that would be deposited by a current of 1.5A flowing in 1 hour is', '2g', '10g', '6g', '18g', 'b', 'Answer All Questions', '', '', '', '', ''),
(52, 'A body bf mass 2kg moves round a circle of radius 2m with a constant speed of 20m/s. Calculate the force toward the centre.', '100N', '20N', '400N', '80N', 'c', 'Answer All Questions', '', '', '', '', ''),
(53, 'In the diagram above, determine the r.m.s. current. ', '60A', '80A', '44A', '48A', 'c', 'Answer All Questions', 'phy6.png', '', '', '', ''),
(54, 'Which of the following graphs correctly represents the variation of mass of a given material deposited with time for constant current in Faraday\'s Law of Electrolysis?', 'graph A ', 'graph B', 'graph C', 'graph D', 'a', 'Answer All Questions', 'phy7.png', '', '', '', ''),
(55, 'The primary coil of a transformer has N turns and is connected to a 120V a.c. power line. If the secondary coil has 1000 turns and a terminal voltage of 1200 volts, what is the value of N?', '1000', '1200', '120', '100', 'd', 'Answer All Questions', '', '', '', '', ''),
(56, '', '4.0J', '1.2J', '2.0J', '12.0J', 'c', 'Answer All Questions', 'phy8.JPG', '', '', '', ''),
(57, 'The process of energy production in the sun is', 'Nuclear fission', 'Nuclear fusion', 'radioactive decay', 'electron collision', 'b', 'Answer All Questions', '', '', '', '', ''),
(58, 'In the diagram above, the current I is', '9/11 A', '3/8 A', '8/3 A', '12/11 A', 'd', 'Answer All Questions', 'phy9.png', '', '', '', ''),
(59, '', '4V, 6V and 2V', '6V, 2V and 4V', '6V, 4V and 2V', '2V, 6V and 4V', 'b', 'Answer All Questions', 'phy10.JPG', '', '', '', ''),
(60, 'A working electric motor takes a current of 1.5A when the p.d. across it is 250V. If its efficiency is 80%, the power output is', '4.8W', '133.0W', '300.0W', '469.0W', 'c', 'Answer All Questions', '', '', '', '', ''),
(61, 'The cost of running five 60W lamps and four 100W lamps for 20 hours if electrical energy costs N10.00 per KWh is', 'N280.00', 'N160.00', 'N120.00', 'N140.00', 'd', 'Answer All Questions', '', '', '', '', ''),
(62, 'The resultant of two forces acting on an object is maximum if the angle between them is', '180(degrees)', '0(degrees)', '45(degrees)', '90(degrees)', 'b', 'Answer All Questions', '', '', '', '', ''),
(63, 'The efficiency of a machine is always less than 100% because the', 'velocity ratio is always greater than the mechanical advantage', 'work output is always greater than the work input', 'effort applied is always greater than the load lifted', 'load lifted is always greater than the effort applied', 'a', 'Answer All Questions', '', '', '', '', ''),
(64, 'A body of mass 5kg starts from rest and is acted upon by a force 100N, the acceleration in ms-2 and final velocity after \r\n10secs will be', '20ms-2, 20ms-1', '25ms-2, 250ms-1', '20ms-2, 200ms-1', '10ms-2, 300ms-1', 'c', 'Answer All Questions', '', '', '', '', ''),
(65, 'In order to find the depth of the sea, a ship sends out a sound wave and receives an echo after 1 second. If the velocity of sound in water is 1500ms-1, what is the depth of the sea?', '0.75km', '1.50km', '2.20km', '3.00km', 'a', 'Answer All Questions', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

CREATE TABLE `scores` (
  `sn` int(3) NOT NULL,
  `un` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sub2` varchar(100) NOT NULL,
  `sub3` varchar(100) NOT NULL,
  `sub4` varchar(100) NOT NULL,
  `score1` int(11) NOT NULL,
  `score2` int(11) NOT NULL,
  `score3` int(11) NOT NULL,
  `score4` int(11) NOT NULL,
  `tscore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `second_class`
--

CREATE TABLE `second_class` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `second_class`
--

INSERT INTO `second_class` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The novelist of the novel is ', 'Buchi Emecheta', 'Tony Chukwuka', 'Toyonsi  Adesanya', 'Wale Soyinka', 'a', 'Questions Based on SECOND CLASS CITIZEN', '', '', '', '', ''),
(2, 'The novel reveals the --------- of the novelist.', 'history ', 'autobiography ', 'biography ', 'dream', 'b', 'Questions Based on SECOND CLASS CITIZEN', '', '', '', '', ''),
(3, 'Adah Ofili was denied education because of her------', 'gender ', 'age ', 'family background ', 'stubbornness', 'a', 'Questions Based on SECOND CLASS CITIZEN', '', '', '', '', ''),
(4, 'Adah Ofili divorced Francis Obi for', 'making her pregnant for the fourth child', 'not assisting her in house chores', 'destroying her manuscript', 'being hot tempered', 'c', 'Questions Based on SECOND CLASS CITIZEN', '', '', '', '', ''),
(5, 'Adah Ofili chose to marry very early in order to ', 'have a home', 'have a family ', 'have children', 'have a husband', 'a', 'Questions Based on SECOND CLASS CITIZEN', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `song_of_women`
--

CREATE TABLE `song_of_women` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `song_of_women`
--

INSERT INTO `song_of_women` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, '\"forlorn field\" inscribes ', 'hopefulness ', 'hopelessness ', 'loneliness ', 'rejection', 'b', 'Questions Based on THE SONG OF THE WOMEN OF MY LAND\r\n\r\nToday the tune roams the forlorn field\r\nLike their souls looking for lyrics\r\nTo tell the tale of the servitude\r\nOf the women of my land\r\n', '', '', '', '', ''),
(2, 'The second line of the above poem illustrate ', 'simile ', 'metaphor ', 'paradox ', 'oxymoron', 'a', 'Questions Based on THE SONG OF THE WOMEN OF MY LAND\r\n\r\nToday the tune roams the forlorn field\r\nLike their souls looking for lyrics\r\nTo tell the tale of the servitude\r\nOf the women of my land\r\n', '', '', '', '', ''),
(3, 'The rhyming scheme of the above poem is', 'aabb ', 'abab ', 'bbaa ', 'abcd', 'd', 'Questions Based on THE SONG OF THE WOMEN OF MY LAND\r\n\r\nToday the tune roams the forlorn field\r\nLike their souls looking for lyrics\r\nTo tell the tale of the servitude\r\nOf the women of my land\r\n', '', '', '', '', ''),
(4, 'One of the themes of the poem above is ', 'female slave trade', 'female education ', 'female empowerment', 'feminism', 'a', 'Questions Based on THE SONG OF THE WOMEN OF MY LAND\r\n\r\nToday the tune roams the forlorn field\r\nLike their souls looking for lyrics\r\nTo tell the tale of the servitude\r\nOf the women of my land\r\n', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `unexpected`
--

CREATE TABLE `unexpected` (
  `id` int(11) NOT NULL,
  `qtext` text NOT NULL,
  `atext` varchar(500) NOT NULL,
  `btext` varchar(500) NOT NULL,
  `ctext` varchar(500) NOT NULL,
  `dtext` varchar(500) NOT NULL,
  `ans` char(1) NOT NULL,
  `instruction` longtext NOT NULL,
  `qimage` varchar(200) NOT NULL,
  `aimage` varchar(200) NOT NULL,
  `bimage` varchar(200) NOT NULL,
  `cimage` varchar(200) NOT NULL,
  `dimage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unexpected`
--

INSERT INTO `unexpected` (`id`, `qtext`, `atext`, `btext`, `ctext`, `dtext`, `ans`, `instruction`, `qimage`, `aimage`, `bimage`, `cimage`, `dimage`) VALUES
(1, 'The novel is set between two west African countries', 'Togo and Nigeria', 'Ghana and Cameron', 'Nigeria and Togo ', 'Nigeria and Ghana', 'd', 'Questions Based on UNEXPECTED JOY AT DAWN', '', '', '', '', ''),
(2, 'Who died during a mining operation?', 'Tally O ', 'Jeo ', 'Nii ', 'Marshak', 'a', 'Questions Based on UNEXPECTED JOY AT DAWN', '', '', '', '', ''),
(3, 'One of the dominant themes in the novel is', 'African- American', 'Discrimination ', 'Xenophobia ', 'Cultural inequality', 'c', 'Questions Based on UNEXPECTED JOY AT DAWN', '', '', '', '', ''),
(4, 'The two major characters in the novel are seeking for', 'reunion ', 'marriage ', 'friendship ', 'relationship', 'a', 'Questions Based on UNEXPECTED JOY AT DAWN', '', '', '', '', ''),
(5, 'The novel showcases the ------- of some West African States', 'unity ', 'failures ', 'poverty ', 'riches', 'b', 'Questions Based on UNEXPECTED JOY AT DAWN', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `biology`
--
ALTER TABLE `biology`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `black_woman`
--
ALTER TABLE `black_woman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `caged_bird`
--
ALTER TABLE `caged_bird`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chemistry`
--
ALTER TABLE `chemistry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commerce`
--
ALTER TABLE `commerce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crs`
--
ALTER TABLE `crs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `die_alone`
--
ALTER TABLE `die_alone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `economics`
--
ALTER TABLE `economics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eng1`
--
ALTER TABLE `eng1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eng2`
--
ALTER TABLE `eng2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eng3`
--
ALTER TABLE `eng3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `english_passage`
--
ALTER TABLE `english_passage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engpass`
--
ALTER TABLE `engpass`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fences`
--
ALTER TABLE `fences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `good_morrow`
--
ALTER TABLE `good_morrow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `government`
--
ALTER TABLE `government`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leader_led`
--
ALTER TABLE `leader_led`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `life_changer`
--
ALTER TABLE `life_changer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lion_jewel`
--
ALTER TABLE `lion_jewel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `literature`
--
ALTER TABLE `literature`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `mathematics`
--
ALTER TABLE `mathematics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `midsummer`
--
ALTER TABLE `midsummer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `physics`
--
ALTER TABLE `physics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `second_class`
--
ALTER TABLE `second_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `song_of_women`
--
ALTER TABLE `song_of_women`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unexpected`
--
ALTER TABLE `unexpected`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `biology`
--
ALTER TABLE `biology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `black_woman`
--
ALTER TABLE `black_woman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `caged_bird`
--
ALTER TABLE `caged_bird`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chemistry`
--
ALTER TABLE `chemistry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `commerce`
--
ALTER TABLE `commerce`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `crs`
--
ALTER TABLE `crs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `die_alone`
--
ALTER TABLE `die_alone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `economics`
--
ALTER TABLE `economics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `eng1`
--
ALTER TABLE `eng1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `eng2`
--
ALTER TABLE `eng2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `eng3`
--
ALTER TABLE `eng3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `english_passage`
--
ALTER TABLE `english_passage`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `engpass`
--
ALTER TABLE `engpass`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `fences`
--
ALTER TABLE `fences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `good_morrow`
--
ALTER TABLE `good_morrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `government`
--
ALTER TABLE `government`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `leader_led`
--
ALTER TABLE `leader_led`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `life_changer`
--
ALTER TABLE `life_changer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `lion_jewel`
--
ALTER TABLE `lion_jewel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `literature`
--
ALTER TABLE `literature`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `sn` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;

--
-- AUTO_INCREMENT for table `mathematics`
--
ALTER TABLE `mathematics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `midsummer`
--
ALTER TABLE `midsummer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `physics`
--
ALTER TABLE `physics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `sn` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `second_class`
--
ALTER TABLE `second_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `song_of_women`
--
ALTER TABLE `song_of_women`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `unexpected`
--
ALTER TABLE `unexpected`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
